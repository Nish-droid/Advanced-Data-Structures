Nischay Modi
115788374
7/11 ---Oh yeah! I have been there.

Meesh quest

Got part0 canonical and modified it.
Also got helped from online websites on how to implement treeMaps with comparator 

Modifying part1 canonical to set up PMQuadtree from PRQuadtree by introducing additional 
fields required to support road functionality.

These modifications were also motivated by the meesh-spec provided as a guide to implement.

Not using AvlGNode class instead following the treemap implementation procedure to do this .java file.

Edit: Changed to AvlGNode finally after reading pointers on piazza and classmates recommended me.

Did ShortestPath by myself but got help from geeksForgeeks just to get an idea of 
using adjacency list.

Got help from a TA about HTML in shortest path

AvlTree in sortedMap is a copied version of rosetta code as mentioned in spec.

Thank you for introducing such a project! 