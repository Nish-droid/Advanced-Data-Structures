/**
 * Using this treemap implementation from docjar just as a refernce to implement avlgtree
 */


//package cmsc420.sortedmap;
//
//import java.util.AbstractCollection;
//import java.util.AbstractMap;
//import java.util.AbstractSet;
//import java.util.Comparator;
//import java.util.Iterator;
//import java.util.Map;
//import java.util.NavigableMap;
//import java.util.NavigableSet;
//import java.util.NoSuchElementException;
//import java.util.SortedMap;
//
//public class TreeMap<K,V> extends AbstractMap<K,V> implements NavigableMap<K,V>, Cloneable, java.io.Serializable
//{
//	/**
//	 * The comparator used to maintain order in this tree map, or
//	 * null if it uses the natural ordering of its keys.
//	 *
//	 * @serial
//	 */
//	private final Comparator<? super K> comparator;
//
//	private transient Entry<K,V> root = null;
//
//	/**
//	 * The number of entries in the tree
//	 */
//	private transient int size = 0;
//
//	/**
//	 * The number of structural modifications to the tree.
//	 */
//	private transient int modCount = 0;
//
//	public TreeMap() {
//		comparator = null;
//	}
//
//	public TreeMap(Comparator<? super K> comparator) {
//		this.comparator = comparator;
//	}
//
//
//	public TreeMap(Map<? extends K, ? extends V> m) {
//		comparator = null;
//		putAll(m);
//	}
//
//	public TreeMap(SortedMap<K, ? extends V> m) {
//		comparator = m.comparator();
//		try {
//			buildFromSorted(m.size(), m.entrySet().iterator(), null, null);
//		} catch (java.io.IOException cannotHappen) {
//		} catch (ClassNotFoundException cannotHappen) {
//		}
//	}
//
//
//	// Query Operations
//
//	/**
//205        * Returns the number of key-value mappings in this map.
//206        *
//207        * @return the number of key-value mappings in this map
//208        */
//	public int size() {
//		return size;
//	}
//
//	/**
//	 * Returns {@code true} if this map contains a mapping for the specified
//	 * key.
//	 *
//	 * @param key key whose presence in this map is to be tested
//	 * @return {@code true} if this map contains a mapping for the
//	 *         specified key
//	 * @throws ClassCastException if the specified key cannot be compared
//	 *         with the keys currently in the map
//	 * @throws NullPointerException if the specified key is null
//	 *         and this map uses natural ordering, or its comparator
//	 *         does not permit null keys
//	 */
//	public boolean containsKey(Object key) {
//		return getEntry(key) != null;
//	}
//
//	public boolean containsValue(Object value) {
//		for (Entry<K,V> e = getFirstEntry(); e != null; e = successor(e))
//			if (valEquals(value, e.value))
//				return true;
//		return false;
//	}
//
//	public V get(Object key) {
//		Entry<K,V> p = getEntry(key);
//		return (p==null ? null : p.value);
//	}
//
//	public Comparator<? super K> comparator() {
//		return comparator;
//	}
//
//	/**
//282        * @throws NoSuchElementException {@inheritDoc}
//283        */
//	public K firstKey() {
//		return key(getFirstEntry());
//	}
//
//	/**
//289        * @throws NoSuchElementException {@inheritDoc}
//290        */
//	public K lastKey() {
//		getLastEntry();
//		return key(getLastEntry());
//	}
//
//	public void putAll(Map<? extends K, ? extends V> map) {
//		int mapSize = map.size();
//		if (size==0 && mapSize!=0 && map instanceof SortedMap) {
//			Comparator c = ((SortedMap)map).comparator();
//			if (c == comparator || (c != null && c.equals(comparator))) {
//				++modCount;
//				try {
//					buildFromSorted(mapSize, map.entrySet().iterator(),
//							null, null);
//				} catch (java.io.IOException cannotHappen) {
//				} catch (ClassNotFoundException cannotHappen) {
//				}
//				return;
//			}
//		}
//		super.putAll(map);
//	}
//
//	final Entry<K,V> getEntry(Object key) {
//		// Offload comparator-based version for sake of performance
//		if (comparator != null)
//			return getEntryUsingComparator(key);
//		if (key == null)
//			throw new NullPointerException();
//		Comparable<? super K> k = (Comparable<? super K>) key;
//		Entry<K,V> p = root;
//		while (p != null) {
//			int cmp = k.compareTo(p.key);
//			if (cmp < 0)
//				p = p.left;
//			else if (cmp > 0)
//				p = p.right;
//			else
//				return p;
//		}
//		return null;
//	}
//
//	final Entry<K,V> getEntryUsingComparator(Object key) {
//		K k = (K) key;
//		Comparator<? super K> cpr = comparator;
//		if (cpr != null) {
//			Entry<K,V> p = root;
//			while (p != null) {
//				int cmp = cpr.compare(k, p.key);
//				if (cmp < 0)
//					p = p.left;
//				else if (cmp > 0)
//					p = p.right;
//				else
//					return p;
//			}
//		}
//		return null;
//	}
//
//	final Entry<K,V> getCeilingEntry(K key) {
//		Entry<K,V> p = root;
//		while (p != null) {
//			int cmp = compare(key, p.key);
//			if (cmp < 0) {
//				if (p.left != null)
//					p = p.left;
//				else
//					return p;
//			} else if (cmp > 0) {
//				if (p.right != null) {
//					p = p.right;
//				} else {
//					Entry<K,V> parent = p.parent;
//					Entry<K,V> ch = p;
//					while (parent != null && ch == parent.right) {
//						ch = parent;
//						parent = parent.parent;
//					}
//					return parent;
//				}
//			} else
//				return p;
//		}
//		return null;
//	}
//
//	final Entry<K,V> getFloorEntry(K key) {
//		Entry<K,V> p = root;
//		while (p != null) {
//			int cmp = compare(key, p.key);
//			if (cmp > 0) {
//				if (p.right != null)
//					p = p.right;
//				else
//					return p;
//			} else if (cmp < 0) {
//				if (p.left != null) {
//					p = p.left;
//				} else {
//					Entry<K,V> parent = p.parent;
//					Entry<K,V> ch = p;
//					while (parent != null && ch == parent.left) {
//						ch = parent;
//						parent = parent.parent;
//					}
//					return parent;
//				}
//			} else
//				return p;
//
//		}
//		return null;
//	}
//
//	final Entry<K,V> getHigherEntry(K key) {
//		Entry<K,V> p = root;
//		while (p != null) {
//			int cmp = compare(key, p.key);
//			if (cmp < 0) {
//				if (p.left != null)
//					p = p.left;
//				else
//					return p;
//			} else {
//				if (p.right != null) {
//					p = p.right;
//				} else {
//					Entry<K,V> parent = p.parent;
//					Entry<K,V> ch = p;
//					while (parent != null && ch == parent.right) {
//						ch = parent;
//						parent = parent.parent;
//					}
//					return parent;
//				}
//			}
//		}
//		return null;
//	}
//
//	final Entry<K,V> getLowerEntry(K key) {
//		Entry<K,V> p = root;
//		while (p != null) {
//			int cmp = compare(key, p.key);
//			if (cmp > 0) {
//				if (p.right != null)
//					p = p.right;
//				else
//					return p;
//			} else {
//				if (p.left != null) {
//					p = p.left;
//				} else {
//					Entry<K,V> parent = p.parent;
//					Entry<K,V> ch = p;
//					while (parent != null && ch == parent.left) {
//						ch = parent;
//						parent = parent.parent;
//					}
//					return parent;
//				}
//			}
//		}
//		return null;
//	}
//
//	public V put(K key, V value) {
//		Entry<K,V> t = root;
//		if (t == null) {
//			compare(key, key); // type (and possibly null) check
//
//			root = new Entry<>(key, value, null);
//			size = 1;
//			modCount++;
//			return null;
//		}
//		int cmp;
//		Entry<K,V> parent;
//		// split comparator and comparable paths
//		Comparator<? super K> cpr = comparator;
//		if (cpr != null) {
//			do {
//				parent = t;
//				cmp = cpr.compare(key, t.key);
//				if (cmp < 0)
//					t = t.left;
//				else if (cmp > 0)
//					t = t.right;
//				else
//					return t.setValue(value);
//			} while (t != null);
//		}
//		else {
//			if (key == null)
//				throw new NullPointerException();
//			Comparable<? super K> k = (Comparable<? super K>) key;
//			do {
//				parent = t;
//				cmp = k.compareTo(t.key);
//				if (cmp < 0)
//					t = t.left;
//				else if (cmp > 0)
//					t = t.right;
//				else
//					return t.setValue(value);
//			} while (t != null);
//		}
//		Entry<K,V> e = new Entry<>(key, value, parent);
//		if (cmp < 0)
//			parent.left = e;
//		else
//			parent.right = e;
//		fixAfterInsertion(e);
//		size++;
//		modCount++;
//		return null;
//	}
//
//	public V remove(Object key) {
//		Entry<K,V> p = getEntry(key);
//		if (p == null)
//			return null;
//
//		V oldValue = p.value;
//		deleteEntry(p);
//		return oldValue;
//	}
//
//	public void clear() {
//		modCount++;
//		size = 0;
//		root = null;
//	}
//
//
//	public Object clone() {
//		TreeMap<K,V> clone = null;
//		try {
//			clone = (TreeMap<K,V>) super.clone();
//		} catch (CloneNotSupportedException e) {
//			throw new InternalError();
//		}
//
//		// Put clone into "virgin" state (except for comparator)
//		clone.root = null;
//		clone.size = 0;
//		clone.modCount = 0;
//		clone.entrySet = null;
//		clone.navigableKeySet = null;
//		clone.descendingMap = null;
//
//		// Initialize clone with our mappings
//		try {
//			clone.buildFromSorted(size, entrySet().iterator(), null, null);
//		} catch (java.io.IOException cannotHappen) {
//		} catch (ClassNotFoundException cannotHappen) {
//		}
//
//		return clone;
//	}
//
//
//	public Map.Entry<K,V> firstEntry() {
//		return exportEntry(getFirstEntry());
//	}
//
//	public Map.Entry<K,V> lastEntry() {
//		return exportEntry(getLastEntry());
//	}
//
//	public Map.Entry<K,V> pollFirstEntry() {
//		Entry<K,V> p = getFirstEntry();
//		Map.Entry<K,V> result = exportEntry(p);
//		if (p != null)
//			deleteEntry(p);
//		return result;
//	}
//
//	public Map.Entry<K,V> pollLastEntry() {
//		Entry<K,V> p = getLastEntry();
//		Map.Entry<K,V> result = exportEntry(p);
//		if (p != null)
//			deleteEntry(p);
//		return result;
//	}
//
//	public Map.Entry<K,V> lowerEntry(K key) {
//		return exportEntry(getLowerEntry(key));
//	}
//	public K lowerKey(K key) {
//		return keyOrNull(getLowerEntry(key));
//	}
//	public Map.Entry<K,V> floorEntry(K key) {
//		return exportEntry(getFloorEntry(key));
//	}
//	public K floorKey(K key) {
//		return keyOrNull(getFloorEntry(key));
//	}
//
//	public Map.Entry<K,V> ceilingEntry(K key) {
//		return exportEntry(getCeilingEntry(key));
//	}
//	public K ceilingKey(K key) {
//		return keyOrNull(getCeilingEntry(key));
//	}
//
//	public Map.Entry<K,V> higherEntry(K key) {
//		return exportEntry(getHigherEntry(key));
//	}
//
//	public K higherKey(K key) {
//		return keyOrNull(getHigherEntry(key));
//	}
//	private transient EntrySet entrySet = null;
//	private transient KeySet<K> navigableKeySet = null;
//	private transient NavigableMap<K,V> descendingMap = null;
//
//	public Set<K> keySet() {
//		return navigableKeySet();
//	}
//
//	public NavigableSet<K> navigableKeySet() {
//		KeySet<K> nks = navigableKeySet;
//		return (nks != null) ? nks : (navigableKeySet = new KeySet(this));
//	}
//
//	public NavigableSet<K> descendingKeySet() {
//		return descendingMap().navigableKeySet();
//	}
//	public Collection<V> values() {
//		Collection<V> vs = values;
//		return (vs != null) ? vs : (values = new Values());
//	}
//
//	public Set<Map.Entry<K,V>> entrySet() {
//		EntrySet es = entrySet;
//		return (es != null) ? es : (entrySet = new EntrySet());
//	}
//
//	public NavigableMap<K, V> descendingMap() {
//		NavigableMap<K, V> km = descendingMap;
//		return (km != null) ? km :
//			(descendingMap = new DescendingSubMap(this,
//					true, null, true,
//					true, null, true));
//	}
//
//	public NavigableMap<K,V> subMap(K fromKey, boolean fromInclusive,
//			K toKey,   boolean toInclusive) {
//		return new AscendingSubMap(this,
//				false, fromKey, fromInclusive,
//				false, toKey,   toInclusive);
//	}
//
//	public NavigableMap<K,V> headMap(K toKey, boolean inclusive) {
//		return new AscendingSubMap(this,
//				true,  null,  true,
//				false, toKey, inclusive);
//	}
//
//	public NavigableMap<K,V> tailMap(K fromKey, boolean inclusive) {
//		return new AscendingSubMap(this,
//				false, fromKey, inclusive,
//				true,  null,    true);
//	}
//
//	public SortedMap<K,V> subMap(K fromKey, K toKey) {
//		return subMap(fromKey, true, toKey, false);
//	}
//
//	public SortedMap<K,V> headMap(K toKey) {
//		return headMap(toKey, false);
//	}
//	public SortedMap<K,V> tailMap(K fromKey) {
//		return tailMap(fromKey, true);
//	}
//
//	class Values extends AbstractCollection<V> {
//		public Iterator<V> iterator() {
//			return new ValueIterator(getFirstEntry());
//		}
//
//		public int size() {
//			return TreeMap.this.size();
//		}
//
//		public boolean contains(Object o) {
//			return TreeMap.this.containsValue(o);
//		}
//
//		public boolean remove(Object o) {
//			for (Entry<K,V> e = getFirstEntry(); e != null; e = successor(e)) {
//				if (valEquals(e.getValue(), o)) {
//					deleteEntry(e);
//					return true;
//				}
//			}
//			return false;
//		}
//
//		public void clear() {
//			TreeMap.this.clear();
//		}
//	}
//
//	class EntrySet extends AbstractSet<Map.Entry<K,V>> {
//		public Iterator<Map.Entry<K,V>> iterator() {
//			return new EntryIterator(getFirstEntry());
//		}
//
//		public boolean contains(Object o) {
//			if (!(o instanceof Map.Entry))
//				return false;
//			Map.Entry<K,V> entry = (Map.Entry<K,V>) o;
//			V value = entry.getValue();
//			Entry<K,V> p = getEntry(entry.getKey());
//			return p != null && valEquals(p.getValue(), value);
//		}
//
//		public boolean remove(Object o) {
//			if (!(o instanceof Map.Entry))
//				return false;
//			Map.Entry<K,V> entry = (Map.Entry<K,V>) o;
//			V value = entry.getValue();
//			Entry<K,V> p = getEntry(entry.getKey());
//			if (p != null && valEquals(p.getValue(), value)) {
//				deleteEntry(p);
//				return true;
//			}
//			return false;
//		}
//
//		public int size() {
//			return TreeMap.this.size();
//		}
//
//		public void clear() {
//			TreeMap.this.clear();
//		}
//	}
//
//	Iterator<K> keyIterator() {
//		return new KeyIterator(getFirstEntry());
//	}
//
//	Iterator<K> descendingKeyIterator() {
//		return new DescendingKeyIterator(getLastEntry());
//	}
//
//	static final class KeySet<E> extends AbstractSet<E> implements NavigableSet<E> {
//		private final NavigableMap<E, Object> m;
//		KeySet(NavigableMap<E,Object> map) { m = map; }
//
//		public Iterator<E> iterator() {
//			if (m instanceof TreeMap)
//				return ((TreeMap<E,Object>)m).keyIterator();
//			else
//				return (Iterator<E>)(((TreeMap.NavigableSubMap)m).keyIterator());
//		}
//
//		public Iterator<E> descendingIterator() {
//			if (m instanceof TreeMap)
//				return ((TreeMap<E,Object>)m).descendingKeyIterator();
//			else
//				return (Iterator<E>)(((TreeMap.NavigableSubMap)m).descendingKeyIterator());
//		}
//
//		public int size() { return m.size(); }
//		public boolean isEmpty() { return m.isEmpty(); }
//		public boolean contains(Object o) { return m.containsKey(o); }
//		public void clear() { m.clear(); }
//		public E lower(E e) { return m.lowerKey(e); }
//		public E floor(E e) { return m.floorKey(e); }
//		public E ceiling(E e) { return m.ceilingKey(e); }
//		public E higher(E e) { return m.higherKey(e); }
//		public E first() { return m.firstKey(); }
//		public E last() { return m.lastKey(); }
//		public Comparator<? super E> comparator() { return m.comparator(); }
//		public E pollFirst() {
//			Map.Entry<E,Object> e = m.pollFirstEntry();
//			return (e == null) ? null : e.getKey();
//		}
//		public E pollLast() {
//			Map.Entry<E,Object> e = m.pollLastEntry();
//			return (e == null) ? null : e.getKey();
//		}
//		public boolean remove(Object o) {
//			int oldSize = size();
//			m.remove(o);
//			return size() != oldSize;
//		}
//		public NavigableSet<E> subSet(E fromElement, boolean fromInclusive,
//				E toElement,   boolean toInclusive) {
//			return new KeySet<>(m.subMap(fromElement, fromInclusive,
//					toElement,   toInclusive));
//		}
//		public NavigableSet<E> headSet(E toElement, boolean inclusive) {
//			return new KeySet<>(m.headMap(toElement, inclusive));
//		}
//		public NavigableSet<E> tailSet(E fromElement, boolean inclusive) {
//			return new KeySet<>(m.tailMap(fromElement, inclusive));
//		}
//		public SortedSet<E> subSet(E fromElement, E toElement) {
//			return subSet(fromElement, true, toElement, false);
//		}
//		public SortedSet<E> headSet(E toElement) {
//			return headSet(toElement, false);
//		}
//		public SortedSet<E> tailSet(E fromElement) {
//			return tailSet(fromElement, true);
//		}
//		public NavigableSet<E> descendingSet() {
//			return new KeySet(m.descendingMap());
//		}
//	}
//
//	abstract class PrivateEntryIterator<T> implements Iterator<T> {
//		Entry<K,V> next;
//		Entry<K,V> lastReturned;
//		int expectedModCount;
//
//		PrivateEntryIterator(Entry<K,V> first) {
//			expectedModCount = modCount;
//			lastReturned = null;
//			next = first;
//		}
//
//		public final boolean hasNext() {
//			return next != null;
//		}
//
//		final Entry<K,V> nextEntry() {
//			Entry<K,V> e = next;
//			if (e == null)
//				throw new NoSuchElementException();
//			if (modCount != expectedModCount)
//				throw new ConcurrentModificationException();
//			next = successor(e);
//			lastReturned = e;
//			return e;
//			1119           }
//
//		final Entry<K,V> prevEntry() {
//			Entry<K,V> e = next;
//			if (e == null)
//				throw new NoSuchElementException();
//			if (modCount != expectedModCount)
//				throw new ConcurrentModificationException();
//			next = predecessor(e);
//			lastReturned = e;
//			return e;
//		}
//
//		public void remove() {
//			if (lastReturned == null)
//				throw new IllegalStateException();
//			if (modCount != expectedModCount)
//				throw new ConcurrentModificationException();
//			// deleted entries are replaced by their successors
//			if (lastReturned.left != null && lastReturned.right != null)
//				next = lastReturned;
//			deleteEntry(lastReturned);
//			expectedModCount = modCount;
//			lastReturned = null;
//		}
//	}
//
//	final class EntryIterator extends PrivateEntryIterator<Map.Entry<K,V>> {
//		EntryIterator(Entry<K,V> first) {
//			super(first);
//		}
//		public Map.Entry<K,V> next() {
//			return nextEntry();
//		}
//	}
//
//	//	1155       final class ValueIterator extends PrivateEntryIterator<V> {
//	//		1156           ValueIterator(Entry<K,V> first) {
//	//			1157               super(first);
//	//			1158           }
//	//		1159           public V next() {
//	//			1160               return nextEntry().value;
//	//			1161           }
//	//		1162       }
//	//	1163   
//	//	1164       final class KeyIterator extends PrivateEntryIterator<K> {
//	//		1165           KeyIterator(Entry<K,V> first) {
//	//			1166               super(first);
//	//			1167           }
//	//		1168           public K next() {
//	//			1169               return nextEntry().key;
//	//			1170           }
//	//		1171       }
//	//	1172   
//	//	1173       final class DescendingKeyIterator extends PrivateEntryIterator<K> {
//	//		1174           DescendingKeyIterator(Entry<K,V> first) {
//	//			1175               super(first);
//	//			1176           }
//	//		1177           public K next() {
//	//			1178               return prevEntry().key;
//	//			1179           }
//	//		1180       }
//	final int compare(Object k1, Object k2) {
//		return comparator==null ? ((Comparable<? super K>)k1).compareTo((K)k2)
//				: comparator.compare((K)k1, (K)k2);
//	}
//
//	static final boolean valEquals(Object o1, Object o2) {
//		return (o1==null ? o2==null : o1.equals(o2));
//	}
//
//	static <K,V> Map.Entry<K,V> exportEntry(TreeMap.Entry<K,V> e) {
//		return (e == null) ? null :
//			new AbstractMap.SimpleImmutableEntry<>(e);
//	}
//	static <K,V> K keyOrNull(TreeMap.Entry<K,V> e) {
//		return (e == null) ? null : e.key;
//	}
//	static <K> K key(Entry<K,?> e) {
//		if (e==null)
//			throw new NoSuchElementException();
//		return e.getKey();
//	}
//	private static final Object UNBOUNDED = new Object();
//	abstract static class NavigableSubMap<K,V> extends AbstractMap<K,V>
//	implements NavigableMap<K,V>, java.io.Serializable {
//		final TreeMap<K,V> m;
//		final K lo, hi;
//		final boolean fromStart, toEnd;
//		final boolean loInclusive, hiInclusive;
//
//		NavigableSubMap(TreeMap<K,V> m,
//				boolean fromStart, K lo, boolean loInclusive,
//				boolean toEnd,     K hi, boolean hiInclusive) {
//			if (!fromStart && !toEnd) {
//				if (m.compare(lo, hi) > 0)
//					throw new IllegalArgumentException("fromKey > toKey");
//			} else {
//				if (!fromStart) // type check
//					m.compare(lo, lo);
//				if (!toEnd)
//					m.compare(hi, hi);
//			}
//
//			this.m = m;
//			this.fromStart = fromStart;
//			this.lo = lo;
//			this.loInclusive = loInclusive;
//			this.toEnd = toEnd;
//			this.hi = hi;
//			this.hiInclusive = hiInclusive;
//		}
//
//		final boolean tooLow(Object key) {
//			if (!fromStart) {
//				int c = m.compare(key, lo);
//				if (c < 0 || (c == 0 && !loInclusive))
//					return true;
//			}
//			return false;
//		}
//		final boolean tooHigh(Object key) {
//			if (!toEnd) {
//				int c = m.compare(key, hi);
//				if (c > 0 || (c == 0 && !hiInclusive))
//					return true;
//			}
//			return false;
//		}
//
//		final boolean inRange(Object key) {
//			return !tooLow(key) && !tooHigh(key);
//		}
//
//		final boolean inClosedRange(Object key) {
//			return (fromStart || m.compare(key, lo) >= 0)
//					&& (toEnd || m.compare(hi, key) >= 0);
//		}
//
//		final boolean inRange(Object key, boolean inclusive) {
//			return inclusive ? inRange(key) : inClosedRange(key);
//		}
//
//		/*
//1312            * Absolute versions of relation operations.
//1313            * Subclasses map to these using like-named "sub"
//1314            * versions that invert senses for descending maps
//1315            */
//
//		final TreeMap.Entry<K,V> absLowest() {
//			TreeMap.Entry<K,V> e =
//					(fromStart ?  m.getFirstEntry() :
//						(loInclusive ? m.getCeilingEntry(lo) :
//							m.getHigherEntry(lo)));
//			return (e == null || tooHigh(e.key)) ? null : e;
//		}
//
//		final TreeMap.Entry<K,V> absHighest() {
//			TreeMap.Entry<K,V> e =
//					(toEnd ?  m.getLastEntry() :
//						(hiInclusive ?  m.getFloorEntry(hi) :
//							m.getLowerEntry(hi)));
//			return (e == null || tooLow(e.key)) ? null : e;
//		}
//
//		final TreeMap.Entry<K,V> absCeiling(K key) {
//			if (tooLow(key))
//				return absLowest();
//			TreeMap.Entry<K,V> e = m.getCeilingEntry(key);
//			return (e == null || tooHigh(e.key)) ? null : e;
//		}
//
//		final TreeMap.Entry<K,V> absHigher(K key) {
//			if (tooLow(key))
//				return absLowest();
//			TreeMap.Entry<K,V> e = m.getHigherEntry(key);
//			return (e == null || tooHigh(e.key)) ? null : e;
//		}
//
//		final TreeMap.Entry<K,V> absFloor(K key) {
//			if (tooHigh(key))
//				return absHighest();
//			TreeMap.Entry<K,V> e = m.getFloorEntry(key);
//			return (e == null || tooLow(e.key)) ? null : e;
//		}
//
//		final TreeMap.Entry<K,V> absLower(K key) {
//			if (tooHigh(key))
//				return absHighest();
//			TreeMap.Entry<K,V> e = m.getLowerEntry(key);
//			return (e == null || tooLow(e.key)) ? null : e;
//		}
//
//		/** Returns the absolute high fence for ascending traversal */
//		final TreeMap.Entry<K,V> absHighFence() {
//			return (toEnd ? null : (hiInclusive ?
//					m.getHigherEntry(hi) :
//						m.getCeilingEntry(hi)));
//		}
//
//		/** Return the absolute low fence for descending traversal  */
//		final TreeMap.Entry<K,V> absLowFence() {
//			return (fromStart ? null : (loInclusive ?
//					m.getLowerEntry(lo) :
//						m.getFloorEntry(lo)));
//		}
//
//		// Abstract methods defined in ascending vs descending classes
//		// These relay to the appropriate absolute versions
//
//		abstract TreeMap.Entry<K,V> subLowest();
//		abstract TreeMap.Entry<K,V> subHighest();
//		abstract TreeMap.Entry<K,V> subCeiling(K key);
//		abstract TreeMap.Entry<K,V> subHigher(K key);
//		abstract TreeMap.Entry<K,V> subFloor(K key);
//		abstract TreeMap.Entry<K,V> subLower(K key);
//
//		/** Returns ascending iterator from the perspective of this submap */
//		abstract Iterator<K> keyIterator();
//
//		/** Returns descending iterator from the perspective of this submap */
//		abstract Iterator<K> descendingKeyIterator();
//
//		// public methods
//
//		public boolean isEmpty() {
//			return (fromStart && toEnd) ? m.isEmpty() : entrySet().isEmpty();
//		}
//
//		public int size() {
//			return (fromStart && toEnd) ? m.size() : entrySet().size();
//		}
//
//		public final boolean containsKey(Object key) {
//			return inRange(key) && m.containsKey(key);
//		}
//
//		public final V put(K key, V value) {
//			if (!inRange(key))
//				throw new IllegalArgumentException("key out of range");
//			return m.put(key, value);
//		}
//
//		public final V get(Object key) {
//			return !inRange(key) ? null :  m.get(key);
//		}
//
//		public final V remove(Object key) {
//			return !inRange(key) ? null : m.remove(key);
//		}
//
//		public final Map.Entry<K,V> ceilingEntry(K key) {
//			return exportEntry(subCeiling(key));
//		}
//
//		public final K ceilingKey(K key) {
//			return keyOrNull(subCeiling(key));
//		}
//
//		public final Map.Entry<K,V> higherEntry(K key) {
//			return exportEntry(subHigher(key));
//		}
//
//		public final K higherKey(K key) {
//			return keyOrNull(subHigher(key));
//		}
//
//		public final Map.Entry<K,V> floorEntry(K key) {
//			return exportEntry(subFloor(key));
//		}
//
//		public final K floorKey(K key) {
//			return keyOrNull(subFloor(key));
//		}
//
//		public final Map.Entry<K,V> lowerEntry(K key) {
//			return exportEntry(subLower(key));
//		}
//
//		public final K lowerKey(K key) {
//			return keyOrNull(subLower(key));
//		}
//
//		public final K firstKey() {
//			return key(subLowest());
//		}
//
//		public final K lastKey() {
//			return key(subHighest());
//		}
//
//		public final Map.Entry<K,V> firstEntry() {
//			return exportEntry(subLowest());
//		}
//
//		public final Map.Entry<K,V> lastEntry() {
//			return exportEntry(subHighest());
//		}
//
//		public final Map.Entry<K,V> pollFirstEntry() {
//			TreeMap.Entry<K,V> e = subLowest();
//			Map.Entry<K,V> result = exportEntry(e);
//			if (e != null)
//				m.deleteEntry(e);
//			return result;
//		}
//
//		public final Map.Entry<K,V> pollLastEntry() {
//			TreeMap.Entry<K,V> e = subHighest();
//			Map.Entry<K,V> result = exportEntry(e);
//			if (e != null)
//				m.deleteEntry(e);
//			return result;
//		}
//
//		// Views
//		transient NavigableMap<K,V> descendingMapView = null;
//		transient EntrySetView entrySetView = null;
//		transient KeySet<K> navigableKeySetView = null;
//
//		public final NavigableSet<K> navigableKeySet() {
//			KeySet<K> nksv = navigableKeySetView;
//			return (nksv != null) ? nksv :
//				(navigableKeySetView = new TreeMap.KeySet(this));
//		}
//
//		public final Set<K> keySet() {
//			return navigableKeySet();
//		}
//
//		public NavigableSet<K> descendingKeySet() {
//			return descendingMap().navigableKeySet();
//		}
//
//		public final SortedMap<K,V> subMap(K fromKey, K toKey) {
//			return subMap(fromKey, true, toKey, false);
//		}
//
//		public final SortedMap<K,V> headMap(K toKey) {
//			return headMap(toKey, false);
//		}
//
//		public final SortedMap<K,V> tailMap(K fromKey) {
//			return tailMap(fromKey, true);
//		}
//
//		// View classes
//
//		abstract class EntrySetView extends AbstractSet<Map.Entry<K,V>> {
//			private transient int size = -1, sizeModCount;
//
//			public int size() {
//				if (fromStart && toEnd)
//					return m.size();
//				if (size == -1 || sizeModCount != m.modCount) {
//					sizeModCount = m.modCount;
//					size = 0;
//					Iterator i = iterator();
//					while (i.hasNext()) {
//						size++;
//						i.next();
//					}
//				}
//				return size;
//			}
//
//			public boolean isEmpty() {
//				TreeMap.Entry<K,V> n = absLowest();
//				return n == null || tooHigh(n.key);
//			}
//
//			public boolean contains(Object o) {
//				//				1540                   if (!(o instanceof Map.Entry))
//				//					1541                       return false;
//				//				1542                   Map.Entry<K,V> entry = (Map.Entry<K,V>) o;
//				//				1543                   K key = entry.getKey();
//				//				1544                   if (!inRange(key))
//				//					1545                       return false;
//				//				1546                   TreeMap.Entry node = m.getEntry(key);
//				//				1547                   return node != null &&
//				//						1548                       valEquals(node.getValue(), entry.getValue());
//				1549               }
//			//			1550   
//			public boolean remove(Object o) {
//				//				1552                   if (!(o instanceof Map.Entry))
//				//					1553                       return false;
//				//				1554                   Map.Entry<K,V> entry = (Map.Entry<K,V>) o;
//				//				1555                   K key = entry.getKey();
//				//				1556                   if (!inRange(key))
//				//					1557                       return false;
//				//				1558                   TreeMap.Entry<K,V> node = m.getEntry(key);
//				//				1559                   if (node!=null && valEquals(node.getValue(),
//				//						1560                                               entry.getValue())) {
//				//					1561                       m.deleteEntry(node);
//				//					1562                       return true;
//				//					1563                   }
//				//				1564                   return false;
//			}
//		}
//
//		abstract class SubMapIterator<T> implements Iterator<T> {
//			TreeMap.Entry<K,V> lastReturned;
//			TreeMap.Entry<K,V> next;
//			final Object fenceKey;
//			int expectedModCount;
//
//			SubMapIterator(TreeMap.Entry<K,V> first,
//					TreeMap.Entry<K,V> fence) {
//				expectedModCount = m.modCount;
//				lastReturned = null;
//				next = first;
//				fenceKey = fence == null ? UNBOUNDED : fence.key;
//			}
//
//			public final boolean hasNext() {
//				return next != null && next.key != fenceKey;
//			}
//
//			final TreeMap.Entry<K,V> nextEntry() {
//				TreeMap.Entry<K,V> e = next;
//				if (e == null || e.key == fenceKey)
//					throw new NoSuchElementException();
//				if (m.modCount != expectedModCount)
//					throw new ConcurrentModificationException();
//				next = successor(e);
//				lastReturned = e;
//				return e;
//			}
//
//			final TreeMap.Entry<K,V> prevEntry() {
//				TreeMap.Entry<K,V> e = next;
//				if (e == null || e.key == fenceKey)
//					throw new NoSuchElementException();
//				if (m.modCount != expectedModCount)
//					throw new ConcurrentModificationException();
//				next = predecessor(e);
//				lastReturned = e;
//				return e;
//			}
//
//			final void removeAscending() {
//				if (lastReturned == null)
//					throw new IllegalStateException();
//				if (m.modCount != expectedModCount)
//					throw new ConcurrentModificationException();
//				// deleted entries are replaced by their successors
//				if (lastReturned.left != null && lastReturned.right != null)
//					next = lastReturned;
//				//									                   m.deleteEntry(lastReturned);
//				//									1620                   lastReturned = null;
//				//									1621                   expectedModCount = m.modCount;
//				//									1622               
//			}
//
//			final void removeDescending() {
//				//									1625                   if (lastReturned == null)
//				//										1626                       throw new IllegalStateException();
//				//									1627                   if (m.modCount != expectedModCount)
//				//										1628                       throw new ConcurrentModificationException();
//				//									1629                   m.deleteEntry(lastReturned);
//				//									1630                   lastReturned = null;
//				//									1631                   expectedModCount = m.modCount;
//				//									1632               
//			}
//		}
//		final class SubMapEntryIterator extends SubMapIterator<Map.Entry<K,V>> {
//			//								1637               SubMapEntryIterator(TreeMap.Entry<K,V> first,
//			//										1638                                   TreeMap.Entry<K,V> fence) {
//			//									1639                   super(first, fence);
//			//									1640               }
//			//								1641               public Map.Entry<K,V> next() {
//			//									1642                   return nextEntry();
//			//									1643               }
//			//								1644               public void remove() {
//			//									1645                   removeAscending();
//			//									1646               }
//		}
//		final class SubMapKeyIterator extends SubMapIterator<K> {
//			//								1650               SubMapKeyIterator(TreeMap.Entry<K,V> first,
//			//										1651                                 TreeMap.Entry<K,V> fence) {
//			//									1652                   super(first, fence);
//			//									1653               }
//			//								1654               public K next() {
//			//									1655                   return nextEntry().key;
//			//									1656               }
//			//								1657               public void remove() {
//			//									1658                   removeAscending();
//			//									1659               }
//			//								1660
//		}
//		final class DescendingSubMapEntryIterator extends SubMapIterator<Map.Entry<K,V>> {
//			//								1663               DescendingSubMapEntryIterator(TreeMap.Entry<K,V> last,
//			//										1664                                             TreeMap.Entry<K,V> fence) {
//			//									1665                   super(last, fence);
//			//									1666               }
//			//								1667   
//			//								1668               public Map.Entry<K,V> next() {
//			//									1669                   return prevEntry();
//			//									1670               }
//			//								1671               public void remove() {
//			//									1672                   removeDescending();
//			//									1673               }
//		}
//
//		final class DescendingSubMapKeyIterator extends SubMapIterator<K> {
//			//								1677               DescendingSubMapKeyIterator(TreeMap.Entry<K,V> last,
//			//										1678                                           TreeMap.Entry<K,V> fence) {
//			//									1679                   super(last, fence);
//			//									1680               }
//			//								1681               public K next() {
//			//									1682                   return prevEntry().key;
//			//									1683               }
//			//								1684               public void remove() {
//			//									1685                   removeDescending();
//			//									1686               }
//			//								1687           }
//		}
//
//		class AscendingSubMap<K,V> extends NavigableSubMap<K,V> {
//
//			AscendingSubMap(TreeMap<K,V> m,
//					boolean fromStart, K lo, boolean loInclusive,
//					boolean toEnd,     K hi, boolean hiInclusive) {
//				super(m, fromStart, lo, loInclusive, toEnd, hi, hiInclusive);
//			}
//
//			public Comparator<? super K> comparator() {
//				return m.comparator();
//			}
//
//			public NavigableMap<K,V> subMap(K fromKey, boolean fromInclusive,
//					K toKey,   boolean toInclusive) {
//				if (!inRange(fromKey, fromInclusive))
//					throw new IllegalArgumentException("fromKey out of range");
//				if (!inRange(toKey, toInclusive))
//					throw new IllegalArgumentException("toKey out of range");
//				return new AscendingSubMap(m,
//						false, fromKey, fromInclusive,
//						false, toKey,   toInclusive);
//			}
//
//			public NavigableMap<K,V> headMap(K toKey, boolean inclusive) {
//				if (!inRange(toKey, inclusive))
//					throw new IllegalArgumentException("toKey out of range");
//				return new AscendingSubMap(m,
//						fromStart, lo,    loInclusive,
//						false,     toKey, inclusive);
//			}
//
//			public NavigableMap<K,V> tailMap(K fromKey, boolean inclusive) {
//				if (!inRange(fromKey, inclusive))
//					throw new IllegalArgumentException("fromKey out of range");
//				return new AscendingSubMap(m, false, fromKey, inclusive, toEnd, hi, hiInclusive);
//			}
//
//			public NavigableMap<K,V> descendingMap() {
//				NavigableMap<K,V> mv = descendingMapView;
//				return (mv != null) ? mv :
//					(descendingMapView =
//					new DescendingSubMap(m,
//							fromStart, lo, loInclusive,
//							toEnd,     hi, hiInclusive));
//			}
//
//			Iterator<K> keyIterator() {
//				return new SubMapKeyIterator(absLowest(), absHighFence());
//			}
//
//			Iterator<K> descendingKeyIterator() {
//				return new DescendingSubMapKeyIterator(absHighest(), absLowFence());
//			}
//
//			final class AscendingEntrySetView extends EntrySetView {
//				public Iterator<Map.Entry<K,V>> iterator() {
//					return new SubMapEntryIterator(absLowest(), absHighFence());
//				}
//			}
//
//			public Set<Map.Entry<K,V>> entrySet() {
//				EntrySetView es = entrySetView;
//				return (es != null) ? es : new AscendingEntrySetView();
//			}
//
//			TreeMap.Entry<K,V> subLowest()       { return absLowest(); }
//			TreeMap.Entry<K,V> subHighest()      { return absHighest(); }
//			TreeMap.Entry<K,V> subCeiling(K key) { return absCeiling(key); }
//			TreeMap.Entry<K,V> subHigher(K key)  { return absHigher(key); }
//			TreeMap.Entry<K,V> subFloor(K key)   { return absFloor(key); }
//			TreeMap.Entry<K,V> subLower(K key)   { return absLower(key); }
//		}
//
//		static final class DescendingSubMap<K,V>  extends NavigableSubMap<K,V> {
//			DescendingSubMap(TreeMap<K,V> m,
//					boolean fromStart, K lo, boolean loInclusive,
//					boolean toEnd,     K hi, boolean hiInclusive) {
//				super(m, fromStart, lo, loInclusive, toEnd, hi, hiInclusive);
//				//				1778           }
//				//			1779   
//				//			1780           private final Comparator<? super K> reverseComparator =
//				//			1781               Collections.reverseOrder(m.comparator);
//				//			1782   
//				//			1783           public Comparator<? super K> comparator() {
//				//				1784               return reverseComparator;
//				//				1785           }
//				//			1786   
//				//			1787           public NavigableMap<K,V> subMap(K fromKey, boolean fromInclusive,
//				//					1788                                           K toKey,   boolean toInclusive) {
//				//				1789               if (!inRange(fromKey, fromInclusive))
//				//					1790                   throw new IllegalArgumentException("fromKey out of range");
//				//				1791               if (!inRange(toKey, toInclusive))
//				//					1792                   throw new IllegalArgumentException("toKey out of range");
//				//				1793               return new DescendingSubMap(m,
//				//						1794                                           false, toKey,   toInclusive,
//				//						1795                                           false, fromKey, fromInclusive);
//				//				1796           }
//				//			1797   
//				//			1798           public NavigableMap<K,V> headMap(K toKey, boolean inclusive) {
//				//				1799               if (!inRange(toKey, inclusive))
//				//					1800                   throw new IllegalArgumentException("toKey out of range");
//				//				1801               return new DescendingSubMap(m,
//				//						1802                                           false, toKey, inclusive,
//				//						1803                                           toEnd, hi,    hiInclusive);
//				//				1804           }
//				//			1805   
//				//			1806           public NavigableMap<K,V> tailMap(K fromKey, boolean inclusive) {
//				//				1807               if (!inRange(fromKey, inclusive))
//				//					1808                   throw new IllegalArgumentException("fromKey out of range");
//				//				1809               return new DescendingSubMap(m,
//				//						1810                                           fromStart, lo, loInclusive,
//				//						1811                                           false, fromKey, inclusive);
//				//				1812           }
//				//			1813   
//				//			1814           public NavigableMap<K,V> descendingMap() {
//				//				1815               NavigableMap<K,V> mv = descendingMapView;
//				//				1816               return (mv != null) ? mv :
//				//					1817                   (descendingMapView =
//				//					1818                    new AscendingSubMap(m,
//				//							1819                                        fromStart, lo, loInclusive,
//				//							1820                                        toEnd,     hi, hiInclusive));
//				//				1821           }
//				//			1822   
//				//			1823           Iterator<K> keyIterator() {
//				//				1824               return new DescendingSubMapKeyIterator(absHighest(), absLowFence());
//				//				1825           }
//				//			1826   
//				//			1827           Iterator<K> descendingKeyIterator() {
//				//				1828               return new SubMapKeyIterator(absLowest(), absHighFence());
//				//				1829           }
//				//			1830   
//				//			1831           final class DescendingEntrySetView extends EntrySetView {
//				//				1832               public Iterator<Map.Entry<K,V>> iterator() {
//				//					1833                   return new DescendingSubMapEntryIterator(absHighest(), absLowFence());
//				//					1834               }
//				//				1835           }
//				//			1836   
//				//			1837           public Set<Map.Entry<K,V>> entrySet() {
//				//				1838               EntrySetView es = entrySetView;
//				//				1839               return (es != null) ? es : new DescendingEntrySetView();
//				//				1840           }
//				//			1841   
//				//			1842           TreeMap.Entry<K,V> subLowest()       { return absHighest(); }
//				//			1843           TreeMap.Entry<K,V> subHighest()      { return absLowest(); }
//				//			1844           TreeMap.Entry<K,V> subCeiling(K key) { return absFloor(key); }
//				//			1845           TreeMap.Entry<K,V> subHigher(K key)  { return absLower(key); }
//				//			1846           TreeMap.Entry<K,V> subFloor(K key)   { return absCeiling(key); }
//				//			1847           TreeMap.Entry<K,V> subLower(K key)   { return absHigher(key); }
//			}
//
//			private class SubMap extends AbstractMap<K,V>
//			implements SortedMap<K,V>, java.io.Serializable {
//				private static final long serialVersionUID = -6520786458950516097L;
//				private boolean fromStart = false, toEnd = false;
//				private K fromKey, toKey;
//				private Object readResolve() {
//					return new AscendingSubMap(TreeMap.this,
//							fromStart, fromKey, true,
//							toEnd, toKey, false);
//				}
//				public Set<Map.Entry<K,V>> entrySet() { throw new InternalError(); }
//				public K lastKey() { throw new InternalError(); }
//				public K firstKey() { throw new InternalError(); }
//				public SortedMap<K,V> subMap(K fromKey, K toKey) { throw new InternalError(); }
//				public SortedMap<K,V> headMap(K toKey) { throw new InternalError(); }
//				public SortedMap<K,V> tailMap(K fromKey) { throw new InternalError(); }
//				public Comparator<? super K> comparator() { throw new InternalError(); }
//			}
//			//		1877   
//			//		1878   
//			//		1879       // Red-black mechanics
//			//		1880   
//			//		1881       private static final boolean RED   = false;
//			//		1882       private static final boolean BLACK = true;
//			//		1883   
//
//
//			final class Entry<K,V> implements Map.Entry<K,V> {
//				K key;
//				V value;
//				Entry<K,V> left = null;
//				Entry<K,V> right = null;
//				Entry<K,V> parent;
//				//boolean color = BLACK;
//
//				/**
//1898            * Make a new cell with given key, value, and parent, and with
//1899            * {@code null} child links, and BLACK color.
//1900            */
//				Entry(K key, V value, Entry<K,V> parent) {
//					this.key = key;
//					this.value = value;
//					this.parent = parent;
//				}
//
//				public K getKey() {
//					return key;
//				}
//				public V getValue() {
//					return value;
//				}
//
//				/**
//1926            * Replaces the value currently associated with the key with the given
//1927            * value.
//1928            *
//1929            * @return the value associated with the key before this method was
//1930            *         called
//1931            */
//				public V setValue(V value) {
//					V oldValue = this.value;
//					this.value = value;
//					return oldValue;
//				}
//
//				public boolean equals(Object o) {
//					if (!(o instanceof Map.Entry))
//						return false;
//					Map.Entry<?,?> e = (Map.Entry<?,?>)o;
//
//					return valEquals(key,e.getKey()) && valEquals(value,e.getValue());
//				}
//
//				public int hashCode() {
//					int keyHash = (key==null ? 0 : key.hashCode());
//					int valueHash = (value==null ? 0 : value.hashCode());
//					return keyHash ^ valueHash;
//				}
//
//				public String toString() {
//					return key + "=" + value;
//				}
//			}
//			final Entry<K,V> getFirstEntry() {
//				Entry<K,V> p = root;
//				if (p != null)
//					while (p.left != null)
//						p = p.left;
//				return p;
//			}
//			final Entry<K,V> getLastEntry() {
//				Entry<K,V> p = root;
//				if (p != null)
//					while (p.right != null)
//						p = p.right;
//				return p;
//			}
//
//
//			static <K,V> TreeMap.Entry<K,V> successor(Entry<K,V> t) {
//				if (t == null)
//					return null;
//				else if (t.right != null) {
//					Entry<K,V> p = t.right;
//					while (p.left != null)
//						p = p.left;
//					return p;
//				} else {
//					Entry<K,V> p = t.parent;
//					Entry<K,V> ch = t;
//					while (p != null && ch == p.right) {
//						ch = p;
//						p = p.parent;
//					}
//					return p;
//				}
//			}
//
//			/**
//2004        * Returns the predecessor of the specified Entry, or null if no such.
//2005       */
//			static <K,V> Entry<K,V> predecessor(Entry<K,V> t) {
//				if (t == null)
//					return null;
//				else if (t.left != null) {
//					Entry<K,V> p = t.left;
//					while (p.right != null)
//						p = p.right;
//					return p;
//				} else {
//					Entry<K,V> p = t.parent;
//					Entry<K,V> ch = t;
//					while (p != null && ch == p.left) {
//						ch = p;
//						p = p.parent;
//					}
//					return p;
//				}
//			}
//
//			private static <K,V> boolean colorOf(Entry<K,V> p) {
//				return (p == null ? BLACK : p.color);
//			}
//			//			   
//			private static <K,V> Entry<K,V> parentOf(Entry<K,V> p) {
//				return (p == null ? null: p.parent);
//				//				2041       }
//				//			2042   
//				//			2043       private static <K,V> void setColor(Entry<K,V> p, boolean c) {
//				//				2044           if (p != null)
//				//					2045               p.color = c;
//				//				2046       }
//				//			2047   
//				//			2048       private static <K,V> Entry<K,V> leftOf(Entry<K,V> p) {
//				//				2049           return (p == null) ? null: p.left;
//				//				2050       }
//				//			2051   
//				//			2052       private static <K,V> Entry<K,V> rightOf(Entry<K,V> p) {
//				//				2053           return (p == null) ? null: p.right;
//				//				2054       }
//				//			2055   
//				//			2056       /** From CLR */
//				//			2057       private void rotateLeft(Entry<K,V> p) {
//				//				2058           if (p != null) {
//				//					2059               Entry<K,V> r = p.right;
//				//					2060               p.right = r.left;
//				//					2061               if (r.left != null)
//				//						2062                   r.left.parent = p;
//				//					2063               r.parent = p.parent;
//				//					2064               if (p.parent == null)
//				//						2065                   root = r;
//				//					2066               else if (p.parent.left == p)
//				//						2067                   p.parent.left = r;
//				//					2068               else
//				//						2069                   p.parent.right = r;
//				//					2070               r.left = p;
//				//					2071               p.parent = r;
//				//					2072           }
//				//				2073       }
//				2074   
//				2075       /** From CLR */
//				2076       private void rotateRight(Entry<K,V> p) {
//					2077           if (p != null) {
//						2078               Entry<K,V> l = p.left;
//						2079               p.left = l.right;
//						2080               if (l.right != null) l.right.parent = p;
//						2081               l.parent = p.parent;
//						2082               if (p.parent == null)
//							2083                   root = l;
//						2084               else if (p.parent.right == p)
//							2085                   p.parent.right = l;
//						2086               else p.parent.left = l;
//						2087               l.right = p;
//						2088               p.parent = l;
//						2089           }
//					2090       }
//				2091   
//				2092       /** From CLR */
//				2093       private void fixAfterInsertion(Entry<K,V> x) {
//					2094           x.color = RED;
//					2095   
//					2096           while (x != null && x != root && x.parent.color == RED) {
//						2097               if (parentOf(x) == leftOf(parentOf(parentOf(x)))) {
//							2098                   Entry<K,V> y = rightOf(parentOf(parentOf(x)));
//							2099                   if (colorOf(y) == RED) {
//								2100                       setColor(parentOf(x), BLACK);
//								2101                       setColor(y, BLACK);
//								2102                       setColor(parentOf(parentOf(x)), RED);
//								2103                       x = parentOf(parentOf(x));
//								2104                   } else {
//									2105                       if (x == rightOf(parentOf(x))) {
//										2106                           x = parentOf(x);
//										2107                           rotateLeft(x);
//										2108                       }
//									2109                       setColor(parentOf(x), BLACK);
//									2110                       setColor(parentOf(parentOf(x)), RED);
//									2111                       rotateRight(parentOf(parentOf(x)));
//									2112                   }
//							2113               } else {
//								2114                   Entry<K,V> y = leftOf(parentOf(parentOf(x)));
//								2115                   if (colorOf(y) == RED) {
//									2116                       setColor(parentOf(x), BLACK);
//									2117                       setColor(y, BLACK);
//									2118                       setColor(parentOf(parentOf(x)), RED);
//									2119                       x = parentOf(parentOf(x));
//									2120                   } else {
//										2121                       if (x == leftOf(parentOf(x))) {
//											2122                           x = parentOf(x);
//											2123                           rotateRight(x);
//											2124                       }
//										2125                       setColor(parentOf(x), BLACK);
//										2126                       setColor(parentOf(parentOf(x)), RED);
//										2127                       rotateLeft(parentOf(parentOf(x)));
//										2                   }
//								2               }
//						0           }
//					1           root.color = BLACK;
//					2       }
//				3   
//				4       /**
//5        * Delete node p, and then rebalance the tree.
//6        */
//				7       private void deleteEntry(Entry<K,V> p) {
//					8           modCount++;
//					9           size--;
//					0   
//					1           // If strictly internal, copy successor's element to p and then make p
//					2           // point to successor.
//					3           if (p.left != null && p.right != null) {
//						4               Entry<K,V> s = successor(p);
//						5               p.key = s.key;
//						6               p.value = s.value;
//						7               p = s;
//						8           } // p has 2 children
//					9   
//					2150           // Start fixup at replacement node, if it exists.
//					2151           Entry<K,V> replacement = (p.left != null ? p.left : p.right);
//					2152   
//					2153           if (replacement != null) {
//						2154               // Link replacement to parent
//						2155               replacement.parent = p.parent;
//						2156               if (p.parent == null)
//							2157                   root = replacement;
//						2158               else if (p == p.parent.left)
//							2159                   p.parent.left  = replacement;
//						2160               else
//							2161                   p.parent.right = replacement;
//						2162   
//						2163               // Null out links so they are OK to use by fixAfterDeletion.
//						2164               p.left = p.right = p.parent = null;
//						2165   
//						2166               // Fix replacement
//						2167               if (p.color == BLACK)
//							2168                   fixAfterDeletion(replacement);
//						2169           } else if (p.parent == null) { // return if we are the only node.
//							2170               root = null;
//							2171           } else { //  No children. Use self as phantom replacement and unlink.
//								2172               if (p.color == BLACK)
//									2173                   fixAfterDeletion(p);
//								2174   
//								2175               if (p.parent != null) {
//									2176                   if (p == p.parent.left)
//										2177                       p.parent.left = null;
//									2178                   else if (p == p.parent.right)
//										2179                       p.parent.right = null;
//									2180                   p.parent = null;
//									2181               }
//								2182           }
//					2183       }
//				2184   
//				2185       /** From CLR */
//				2186       private void fixAfterDeletion(Entry<K,V> x) {
//					2187           while (x != root && colorOf(x) == BLACK) {
//						2188               if (x == leftOf(parentOf(x))) {
//							2189                   Entry<K,V> sib = rightOf(parentOf(x));
//							2190   
//							2191                   if (colorOf(sib) == RED) {
//								2192                       setColor(sib, BLACK);
//								2193                       setColor(parentOf(x), RED);
//								2194                       rotateLeft(parentOf(x));
//								2195                       sib = rightOf(parentOf(x));
//								2196                   }
//							2197   
//							2198                   if (colorOf(leftOf(sib))  == BLACK &&
//							2199                       colorOf(rightOf(sib)) == BLACK) {
//								2200                       setColor(sib, RED);
//								2201                       x = parentOf(x);
//								2202                   } else {
//									2203                       if (colorOf(rightOf(sib)) == BLACK) {
//										2204                           setColor(leftOf(sib), BLACK);
//										2205                           setColor(sib, RED);
//										2206                           rotateRight(sib);
//										2207                           sib = rightOf(parentOf(x));
//										2208                       }
//									2209                       setColor(sib, colorOf(parentOf(x)));
//									2210                       setColor(parentOf(x), BLACK);
//									2211                       setColor(rightOf(sib), BLACK);
//									2212                       rotateLeft(parentOf(x));
//									2                       x = root;
//									2                   }
//							2215               } else { // symmetric
//								2216                   Entry<K,V> sib = leftOf(parentOf(x));
//								2217   
//								2218                   if (colorOf(sib) == RED) {
//									2219                       setColor(sib, BLACK);
//									2220                       setColor(parentOf(x), RED);
//									2221                       rotateRight(parentOf(x));
//									2222                       sib = leftOf(parentOf(x));
//									2223                   }
//								2224   
//								2225                   if (colorOf(rightOf(sib)) == BLACK &&
//								2226                       colorOf(leftOf(sib)) == BLACK) {
//									2227                       setColor(sib, RED);
//									2228                       x = parentOf(x);
//									2229                   } else {
//										2230                       if (colorOf(leftOf(sib)) == BLACK) {
//											2231                           setColor(rightOf(sib), BLACK);
//											2232                           setColor(sib, RED);
//											2233                           rotateLeft(sib);
//											2234                           sib = leftOf(parentOf(x));
//											2235                       }
//										2236                       setColor(sib, colorOf(parentOf(x)));
//										2237                       setColor(parentOf(x), BLACK);
//										2238                       setColor(leftOf(sib), BLACK);
//										2239                       rotateRight(parentOf(x));
//										2240                       x = root;
//										2241                   }
//								2242               }
//						2243           }
//					2244   
//					2245           setColor(x, BLACK);
//					2246       }
//				2247   
//				2248       private static final long serialVersionUID = 919286545866124006L;
//				2249   
//				2250       /**
//2251        * Save the state of the {@code TreeMap} instance to a stream (i.e.,
//2252        * serialize it).
//2253        *
//2254        * @serialData The <em>size</em> of the TreeMap (the number of key-value
//2255        *             mappings) is emitted (int), followed by the key (Object)
//2256        *             and value (Object) for each key-value mapping represented
//2257        *             by the TreeMap. The key-value mappings are emitted in
//2258        *             key-order (as determined by the TreeMap's Comparator,
//2259        *             or by the keys' natural ordering if the TreeMap has no
//2260        *             Comparator).
//2261        */
//				2262       private void writeObject(java.io.ObjectOutputStream s)
//				2263           throws java.io.IOException {
//					2264           // Write out the Comparator and any hidden stuff
//					2265           s.defaultWriteObject();
//					2266   
//					2267           // Write out size (number of Mappings)
//					2268           s.writeInt(size);
//					2269   
//					2270           // Write out keys and values (alternating)
//					2271           for (Iterator<Map.Entry<K,V>> i = entrySet().iterator(); i.hasNext(); ) {
//						2272               Map.Entry<K,V> e = i.next();
//						2273               s.writeObject(e.getKey());
//						2274               s.writeObject(e.getValue());
//						2275           }
//					2276       }
//				2277   
//				2278       /**
//2279        * Reconstitute the {@code TreeMap} instance from a stream (i.e.,
//2280        * deserialize it).
//2281        */
//				2282       private void readObject(final java.io.ObjectInputStream s)
//				2283           throws java.io.IOException, ClassNotFoundException {
//					2284           // Read in the Comparator and any hidden stuff
//					2285           s.defaultReadObject();
//					2286   
//					2287           // Read in size
//					2288           int size = s.readInt();
//					2289   
//					2290           buildFromSorted(size, null, s, null);
//					2291       }
//				2292   
//				2293       /** Intended to be called only from TreeSet.readObject */
//				2294       void readTreeSet(int size, java.io.ObjectInputStream s, V defaultVal)
//				2295           throws java.io.IOException, ClassNotFoundException {
//					2296           buildFromSorted(size, null, s, defaultVal);
//					2297       }
//				2298   
//				2299       /** Intended to be called only from TreeSet.addAll */
//				2300       void addAllForTreeSet(SortedSet<? extends K> set, V defaultVal) {
//					2301           try {
//						2302               buildFromSorted(set.size(), set.iterator(), null, defaultVal);
//						2303           } catch (java.io.IOException cannotHappen) {
//							2304           } catch (ClassNotFoundException cannotHappen) {
//								2305           }
//					2306       }
//
//				private void buildFromSorted(int size, Iterator it,
//						2340                                    java.io.ObjectInputStream str,
//						2341                                    V defaultVal)
//				2342           throws  java.io.IOException, ClassNotFoundException {
//					2343           this.size = size;
//					2344           root = buildFromSorted(0, 0, size-1, computeRedLevel(size),
//							2345                                  it, str, defaultVal);
//					2346       }
//				2347   
//				2348       /**
//2349        * Recursive "helper method" that does the real work of the
//2350        * previous method.  Identically named parameters have
//2351        * identical definitions.  Additional parameters are documented below.
//2352        * It is assumed that the comparator and size fields of the TreeMap are
//2353        * already set prior to calling this method.  (It ignores both fields.)
//2354        *
//2355        * @param level the current level of tree. Initial call should be 0.
//2356        * @param lo the first element index of this subtree. Initial should be 0.
//2357        * @param hi the last element index of this subtree.  Initial should be
//2358        *        size-1.
//2359        * @param redLevel the level at which nodes should be red.
//2360        *        Must be equal to computeRedLevel for tree of this size.
//2361        */
//				2362       private final Entry<K,V> buildFromSorted(int level, int lo, int hi,
//						2363                                                int redLevel,
//						2364                                                Iterator it,
//						2365                                                java.io.ObjectInputStream str,
//						2366                                                V defaultVal)
//				2367           throws  java.io.IOException, ClassNotFoundException {
//					2368           /*
//2369            * Strategy: The root is the middlemost element. To get to it, we
//2370            * have to first recursively construct the entire left subtree,
//2371            * so as to grab all of its elements. We can then proceed with right
//2372            * subtree.
//2373            *
//2374            * The lo and hi arguments are the minimum and maximum
//2375            * indices to pull out of the iterator or stream for current subtree.
//2376            * They are not actually indexed, we just proceed sequentially,
//2377            * ensuring that items are extracted in corresponding order.
//2378            */
//					2379   
//					2380           if (hi < lo) return null;
//					2381   
//					2382           int mid = (lo + hi) >>> 1;
//					2383   
//					2384           Entry<K,V> left  = null;
//					2385           if (lo < mid)
//						2386               left = buildFromSorted(level+1, lo, mid - 1, redLevel,
//								2387                                      it, str, defaultVal);
//					2388   
//					2389           // extract key and/or value from iterator or stream
//					2390           K key;
//					2391           V value;
//					2392           if (it != null) {
//						2393               if (defaultVal==null) {
//							2394                   Map.Entry<K,V> entry = (Map.Entry<K,V>)it.next();
//							2395                   key = entry.getKey();
//							2396                   value = entry.getValue();
//							2397               } else {
//								2398                   key = (K)it.next();
//								2399                   value = defaultVal;
//								2400               }
//						2401           } else { // use stream
//							2402               key = (K) str.readObject();
//							2403               value = (defaultVal != null ? defaultVal : (V) str.readObject());
//							2404           }
//					2405   
//					2406           Entry<K,V> middle =  new Entry<>(key, value, null);
//					2407   
//					2408           // color nodes in non-full bottommost level red
//					2409           if (level == redLevel)
//						2410               middle.color = RED;
//					2411   
//					2412           if (left != null) {
//						2413               middle.left = left;
//						2414               left.parent = middle;
//						2415           }
//					2416   
//					2417           if (mid < hi) {
//						2418               Entry<K,V> right = buildFromSorted(level+1, mid+1, hi, redLevel,
//								2419                                                  it, str, defaultVal);
//						2420               middle.right = right;
//						2421               right.parent = middle;
//						2422           }
//					2423   
//					2424           return middle;
//					2425       }
//				2426   
//				2427       /**
//2428        * Find the level down to which to assign all nodes BLACK.  This is the
//2429        * last `full' level of the complete binary tree produced by
//2430        * buildTree. The remaining nodes are colored RED. (This makes a `nice'
//2431        * set of color assignments wrt future insertions.) This level number is
//2432        * computed by finding the number of splits needed to reach the zeroeth
//2433        * node.  (The answer is ~lg(N), but in any case must be computed by same
//2434        * quick O(lg(N)) loop.)
//2435        */
//				2436       private static int computeRedLevel(int sz) {
//					2437           int level = 0;
//					2438           for (int m = sz - 1; m >= 0; m = m / 2 - 1)
//						2439               level++;
//					2440           return level;
//					2441       }
//				2442   }
