package cmsc420.structure;

import java.awt.geom.Point2D;

/**
 * Metropole class is an analogue to a real-world group of cities in 2D space. 
 * Each metropole contains its coordinates in 2D called remote coordinates.
 * <p>
 * Useful <code>java.awt.geom.Point2D</code> methods (such as distance()) can
 * be utilized by calling toPoint2D(), which creates a Point2D copy of this
 * metropole's location.
 * 
 * @author Ben Zoller
 * @editor Ruofei Du
 * @version 1.0, 19 Feb 2007
 * @revise 1.1, 11 Jun 2014
 */
public class Metropole {
	
	
	/** Coordinates of this metroPole */
	public Point2D.Float pt;

	/**
	 * Constructs a metroPole.
	 * 
	 * @param remoteX
	 *            remoteX coordinate of the metroPole
	 * @param remoteY
	 *            remoteY coordinate of the metroPole
	 */
	public Metropole(int remoteX, final int remoteY) {
		pt = new Point2D.Float(remoteX, remoteY);
	}

	/**
	 * Getters for metroPole's coordinates
	 * @return x and y coordinate
	 */
	public int getRemoteX() {
		return (int) pt.x;
	}

	
	public int getRemoteY() {
		return (int) pt.y;
	}


	/**
	 * Determines if this metroPole is equal to another metroPole. The result is true if
	 * and only if the other metroPole is not null and a metroPole object that contains the
	 * same remote X and Y coordinates.
	 * 
	 * @param obj
	 *            the object to compare this metroPole against
	 * @return <code>true</code> if cities are equal, <code>false</code>
	 *         otherwise
	 */
	public boolean equals(final Object obj) {
		if (obj == this)
			return true;
		if (obj != null && (obj.getClass().equals(this.getClass()))) {
			Metropole m = (Metropole) obj;
			return (pt.equals(m.pt) );
		}
		return false;
	}

	/**
	 * Returns a hash code for this metroPole.
	 * 
	 * @return hash code for this metroPole
	 */
	public int hashCode() {
		int hash = 12;
		hash = 37 * hash + pt.hashCode();
		return hash;
	}

	/**
	 * Returns an (x,y) representation of the metroPole. 
	 * Important: casts the remote x and y coordinates to integers.
	 * 
	 * @return string representing the location of the metroPole
	 */
	public String getLocationString() {
		final StringBuilder location = new StringBuilder();
		location.append("(");
		location.append(getRemoteX());
		location.append(",");
		location.append(getRemoteY());
		location.append(")");
		return location.toString();
	}

	/**
	 * Returns a Point2D instance representing the metroPole's location.
	 * 
	 * @return location of this metroPole
	 */
	public Point2D remotetoPoint2D() {
		return new Point2D.Float(getRemoteX(), getRemoteY());
	}
}