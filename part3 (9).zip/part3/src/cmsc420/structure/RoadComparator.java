package cmsc420.structure ;

import java.util.Comparator;
import cmsc420.structure.pmquadtree.QEdge;

public class RoadComparator implements Comparator<QEdge>{

	@Override
	public int compare(final QEdge q1, final QEdge q2) {
		if (q1.getStartName().equals(q2.getStartName())){
			return q2.getEndName().compareTo(q1.getEndName());
		} else {
			return q2.getStartName().compareTo(q1.getStartName());
		}
	}

//	public int comp(QEdge q1, QEdge q2) {
//		final int x = q1.getStartName().compareTo(q2.getStartName());
//		final int y = q2.getEndName().compareTo(q1.getEndName());
//		
//		return x == 0 ? y: x;
//	}
}