package cmsc420.structure.pmquadtree;

import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.TreeSet;

import cmsc420.structure.City;

/**
 * Node abstract class for a PM Quadtree. A node can either be an empty
 * node (WHITE), a leaf node(BLACK), or an internal node(GRAY).
 * Taken directly from pseudocode from the spec.
 * And also modified it based on the part1 canonical's Node class.
 */
public abstract class Node{
	
	/** Type flag for an empty PM Quadtree node */
	public static final int WHITE = 0;

	/** Type flag for a PM Quadtree leaf node */
	public static final int BLACK = 1;

	/** Type flag for a PM Quadtree internal node */
	public static final int GRAY = 2;

	/** type of PM Quadtree node (either empty, leaf, or internal) */
	protected final int type;

	/**
	 * Constructor for abstract Node class.
	 * 
	 * @param type
	 *            type of the node (either empty, leaf, or internal)
	 */
	protected Node(final int type) {
		this.type = type;
	}

	/**
	 * Adds a city to the node. If an empty node, the node becomes a leaf
	 * node. If a leaf node already, the leaf node becomes an internal node
	 * and both cities are added to it. If an internal node, the city is
	 * added to the child whose quadrant the city is located within.
	 * 
	 * @param city
	 *            city to be added to the PR Quadtree
	 * @param origin
	 *            origin of the rectangular bounds of this node
	 * @param width
	 *            width of the rectangular bounds of this node
	 * @param height
	 *            height of the rectangular bounds of this node
	 * @return this node after the city has been added
	 */
	public abstract Node add(City city, Point2D.Float origin, int width, int height);

	public abstract Node addRoad(QEdge road);
	
	/**
	 * Gets the type of the node (either empty, leaf, or internal).
	 * 
	 * @return type of the node
	 */
	public int getType() {
		return type;
	}
	
	/**
	 * @return city contained by type of 
	 * the implemented node
	 */
	public abstract City getCity();

	public abstract TreeSet<QEdge> getRoads();
}