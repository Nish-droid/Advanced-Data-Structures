package cmsc420.structure.pmquadtree;

import java.awt.geom.Line2D;
import java.util.Objects;

import cmsc420.structure.City;

public class QEdge extends Line2D.Float {

	private static final long serialVersionUID = 1L;

	private City start;
	private City end;

	public QEdge(City city1, City city2){
		super(city1.localPt, city2.localPt);
		start = city1;
		end = city2;
	}

	public String getStartName(){
		return start.getName();
	}

	public String getEndName(){
		return end.getName();
	}

	@Override
	public int hashCode() {
		return Objects.hash(end, start);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QEdge other = (QEdge) obj;
		return Objects.equals(end, other.end) && Objects.equals(start, other.start);
	}

//	public Line2D getRoad() {
//		return new QEdge(start, end);
//	}
}