package cmsc420.structure.pmquadtree;

import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.Color;
import java.util.*;
import cmsc420.utils.Canvas;
import cmsc420.geom.Circle2D;
import cmsc420.structure.City;
import cmsc420.structure.RoadComparator;
import cmsc420.exception.RoadAlreadyMappedException;
import cmsc420.exception.RoadOutOfBoundsException;
import cmsc420.exception.CityAlreadyMappedException;
import cmsc420.exception.CityOutOfBoundsException;

public class PM3QuadTree {

	/**
	 * Taken from the pseudocode in spec of part2
	 * Singleton Set which represents empty node
	 */
	White SingletonWhiteNode = new White();

	/** root of the PM Quadtree */
	protected Node root;

	/** bounds of the spatial map */
	protected Point2D.Float spatialOrigin;

	/** width of the spatial map */
	protected int spatialWidth;

	/** height of the spatial map */
	protected int spatialHeight;
	
	/** order of pm */
	protected int order;

	/** used to keep track of cities within the spatial map */
	protected HashSet<String> cityNames;

	/** used to keep track of roads within the spatial map */
	protected TreeSet<QEdge> roadList;

	/**used to keep track of isolated cities within the map */
	protected HashSet<String> isoCityNames;
	
	protected final HashSet<String> roadPoints = new HashSet<String>();
	
	public PM3QuadTree(){
		root = SingletonWhiteNode;
		cityNames = new HashSet<String>();
		spatialOrigin = new Point2D.Float(0, 0);
		roadList = new TreeSet<QEdge>(new RoadComparator());
		isoCityNames = new HashSet<String>();
	}
	//sets up the PMQuadTree
	public void setRange(int spatialWidth, int spatialHeight) {
		this.spatialWidth = spatialWidth;
		this.spatialHeight = spatialHeight;
	}

	/**
	 * Gets the root node of the PM Quadtree.
	 * 
	 * @return root node of the PM Quadtree
	 */
	public Node getRoot() {
		return root;
	}

	//	public City getCity() {
	//		return root.getCity();
	//	}

	/**
	 * Whether the PM Quadtree has zero or more elements.
	 * 
	 * @return <code>false</code> if the PM Quadtree has at least one non-empty node.
	 *         Otherwise returns <code>true</code>
	 */
	public boolean isEmpty() {
		return (root == SingletonWhiteNode);
	}

	/**
	 * Inserts a city into the spatial map.
	 * 
	 * @param city
	 *            city to be added
	 * @throws CityAlreadyMappedException
	 *             city is already in the spatial map
	 * @throws CityOutOfBoundsException
	 *             city's location is outside the bounds of the spatial map
	 */
	public void add(City city) throws CityAlreadyMappedException, CityOutOfBoundsException{
		if (cityNames.contains(city.getName()) || isoCityNames.contains(city.getName())) {
			/* city already mapped */
			throw new CityAlreadyMappedException();
		}

		/* check bounds */
		int x = (int) city.getLocalX();
		int y = (int) city.getLocalY();
		if (x < spatialOrigin.x || x > spatialWidth || y < spatialOrigin.y || y > spatialHeight) {
			/* city out of bounds */
			throw new CityOutOfBoundsException();
		}

		/* insert city into PMQuadTree */
		//isoCityNames.add(city.getName()); Not sure atm if it is needed
		root = root.add(city, spatialOrigin, spatialWidth, spatialHeight);
	}

	public void addRoad(City start, City end){

		QEdge insert;
		if (start.getName().compareTo(end.getName()) > 0 ){
			insert = new QEdge(end, start);
		} else {
			insert = new QEdge(start, end);
		}

		if (roadList.contains(insert) ){
			//throw new RoadAlreadyMappedException();
		} 

		Rectangle2D.Float test = new Rectangle2D.Float(spatialOrigin.x, spatialOrigin.y,
				spatialWidth, spatialHeight);

		if (!insert.intersects(test)){
			//throw new RoadOutOfBoundsException();
		}

		if (intersects(start.localPt, test)){
			root = root.add(start, spatialOrigin, spatialWidth, spatialHeight);
			cityNames.add(start.getName());
			/* add city to canvas */
			Canvas.instance.addPoint(start.getName(), start.getLocalX(), start.getLocalY(),
					Color.BLACK);
		}
		if (intersects(end.localPt, test)){
			root = root.add(end, spatialOrigin, spatialWidth, spatialHeight);
			cityNames.add(end.getName());
			/* add city to canvas */
			Canvas.instance.addPoint(end.getName(), end.getLocalX(), end.getLocalY(),
					Color.BLACK);
		}

		root = root.addRoad(insert);
		roadList.add(insert);
		roadPoints.add(insert.getStartName());
		roadPoints.add(insert.getEndName());
	}

	public void addCityName(String name) {
		cityNames.add(name);
	}
	
	public void addIso(String name) {
		isoCityNames.add(name);
	}

	/**
	 * Clears the PMQuadtree so it contains no non-empty nodes.
	 */
	public void clear() {
		root = SingletonWhiteNode;
		cityNames.clear();
		isoCityNames.clear();
	}

	/**
	 * Returns whether the PMQuadtree contains a city with the given name.
	 * 
	 * @return true if the city is in the spatial map, false otherwise.
	 */
	public boolean contains(String name) {
		return (isoCityNames.contains(name) || cityNames.contains(name));
	}

	public boolean hasCites() {
		return (!cityNames.isEmpty() || !isoCityNames.isEmpty());
	}
 
	public boolean hasIsoCites() {
		return (!isoCityNames.isEmpty());
	}

	public boolean isInIso(City city) {
		return (isoCityNames.contains(city.getName()));
	}

	public boolean isInIso(String city) {
		return (isoCityNames.contains(city));
	}

	/**
	 * @return true if there aren't any roads, false o/w
	 */
	public boolean hasRoads() {
		return (!roadList.isEmpty());
	}

	/**
	 * Returns if a point lies within a given rectangular bounds 
	 * according to the rules of the PMQuadtree.
	 * 
	 * @param point
	 *            point to be checked
	 * @param rect
	 *            rectangular bounds the point is being checked against
	 * @return true if the point lies within the rectangular bounds, false
	 *         otherwise
	 */
	public boolean intersects(Point2D point, Rectangle2D rect) {
		return (point.getX() >= rect.getMinX() && point.getX() <= rect.getMaxX()
				&& point.getY() >= rect.getMinY() && point.getY() <= rect
				.getMaxY());
	}

	/**
	 * Returns if any part of a circle lies within a given rectangular bounds
	 * according to the rules of the PMQuadtree.
	 * 
	 * @param circle
	 *            circular region to be checked
	 * @param rect
	 *            rectangular bounds the point is being checked against
	 * @return true if the point lies within the rectangular bounds, false
	 *         otherwise
	 */
	public boolean intersects(Circle2D circle, Rectangle2D rect) {
		final double radiusSquared = circle.getRadius() * circle.getRadius();

		/* translate coordinates, placing circle at origin */
		final Rectangle2D.Double r = new Rectangle2D.Double(rect.getX()
				- circle.getCenterX(), rect.getY() - circle.getCenterY(), rect
				.getWidth(), rect.getHeight());

		if (r.getMaxX() < 0) {
			/* rectangle to left of circle center */
			if (r.getMaxY() < 0) {
				/* rectangle in lower left corner */
				return ((r.getMaxX() * r.getMaxX() + r.getMaxY() * r.getMaxY()) < radiusSquared);
			} else if (r.getMinY() > 0) {
				/* rectangle in upper left corner */
				return ((r.getMaxX() * r.getMaxX() + r.getMinY() * r.getMinY()) < radiusSquared);
			} else {
				/* rectangle due west of circle */
				return (Math.abs(r.getMaxX()) < circle.getRadius());
			}
		} else if (r.getMinX() > 0) {
			/* rectangle to right of circle center */
			if (r.getMaxY() < 0) {
				/* rectangle in lower right corner */
				return ((r.getMinX() * r.getMinX() + r.getMaxY() * r.getMaxY()) < radiusSquared);
			} else if (r.getMinY() > 0) {
				/* rectangle in upper right corner */
				return ((r.getMinX() * r.getMinX() + r.getMinY() * r.getMinY()) < radiusSquared);
			} else {
				/* rectangle due east of circle */
				return (r.getMinX() <= circle.getRadius());
			}
		} else {
			/* rectangle on circle vertical centerline */
			if (r.getMaxY() < 0) {
				/* rectangle due south of circle */
				return (Math.abs(r.getMaxY()) < circle.getRadius());
			} else if (r.getMinY() > 0) {
				/* rectangle due north of circle */
				return (r.getMinY() <= circle.getRadius());
			} else {
				/* rectangle contains circle center point */
				return true;
			}
		}
	}

	public TreeSet<QEdge> getRoadList() {
		return roadList;
	}

	public QEdge closestRoad(Point2D point) {

		QEdge min = null;
		Iterator<QEdge> it = roadList.iterator();

		QEdge current = null;
		int minim = Integer.MAX_VALUE;
		int dist;

		while (it.hasNext()) {
			current = it.next();
			dist = (int)current.ptSegDist(point);
			if(dist < minim) {
				minim = dist;
				min = current;
			}
		}		
		return min;
	}
	
	/**
	 * Sets the pm order.
	 *
	 * @param order the order of the pm quadtree.
	 */
	public void setOrder(int order) {
		this.order = order;
	}
	
	public TreeSet<QEdge> getRoads() {
		return root.getRoads();
	}
	
	public HashSet<String> getCityNames() {
		return cityNames;
	}
	public boolean containRoad(String roadPoint) {
		return roadPoints.contains(roadPoint);
	}
	
	public HashSet<String> getRoadPoints() {
		return roadPoints;
	}
	public void removeRoad(String startName, String endName) {
		// TODO Auto-generated method stub
		
	}
	public void removeCity(String startName) {
		// TODO Auto-generated method stub
		
	}
	public boolean removeCity(City deletedCity) {
		// TODO Auto-generated method stub
		return false;
	}
}