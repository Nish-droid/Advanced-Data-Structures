package cmsc420.structure.pmquadtree;

import java.util.ArrayList;
import java.util.TreeSet;
import java.awt.geom.Point2D.Float;
import cmsc420.structure.City;
import cmsc420.structure.RoadComparator;

/**
 * Represents a leaf node of a PMQuadtree.
 */
public class Black extends Node {
	/** roads contained within this set */
	protected TreeSet <QEdge> roads = new TreeSet<QEdge>(new RoadComparator());
	
	/** city contained within this leaf node */
	protected City city;

	/**
	 * Constructs and initializes a leaf node.
	 */
	public Black(){
		super(Node.BLACK);
	}

	/**
	 * 
	 * @return true if city has been added to the PMQuadtree
	 * o/w false
	 */
	public boolean hasCity(){
		return (city == null) ? false : true;
	}

	/**
	 * 
	 * @return true if roads connecting cities 
	 * has been added to the PMQuadtree
	 * o/w false
	 */
	public boolean hasCityRoads(){
		return (city == null) ? false : true;
	}

	/**
	 * Gets the city contained by this node.
	 * 
	 * @return city contained by this node
	 */
	public City getCity() {
		return city;
	}

	@Override
	public Node add(City newCity, Float origin, int width, int height) {
		if (city == null || city.equals(newCity)) {
			/* node is empty, add city */
			city = newCity;
			return this;
		} else {
			/* node is full, partition node and then add city */
			Gray grayNode = new Gray(origin, width, height);
			grayNode.add(city, origin, width, height);
			grayNode.add(newCity, origin, width, height);
			for (QEdge road : roads){
				grayNode.addRoad(road);
			}
			return grayNode;
		}
	}

	@Override
	public Node addRoad(QEdge road) {
		if (roads.contains(road)){
			return this;
		}
		roads.add(road);
		return this;
	}

	public int getRoadsSize(){
		return roads.size();
	}
	
	/**
	 * Gets the city contained by this node.
	 * 
	 * @return city contained by this node
	 */
	public TreeSet<QEdge> getRoads() {
		return roads;
	}
}

