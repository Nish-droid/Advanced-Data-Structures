package cmsc420.structure.pmquadtree;

/**
 * Taken directly from EmptyNode.java from the canonical
 * Modified it for PMQuadtree
 */
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.TreeSet;

import cmsc420.structure.City;

public class White extends Node{

	/**
	 * Constructs and initializes an empty node.
	 */
	public White() {
		super(Node.WHITE);
	}

	public Node add(City city, Point2D.Float origin, int width, int height) {
		Node blackNode = new Black();
		return blackNode.add(city, origin, width, height);
	}

	public Node addRoad(QEdge road) {
		Node blackNode = new Black();
		return blackNode.addRoad(road);
	}
	public Node remove(City city, Point2D.Float origin, int width,
			int height) {
		/* should never get here, nothing to remove */
		throw new IllegalArgumentException();
	}

	@Override
	public City getCity() {
		throw new IllegalArgumentException();
	}

	@Override
	public TreeSet<QEdge> getRoads() {
		throw new IllegalArgumentException();
	}
}