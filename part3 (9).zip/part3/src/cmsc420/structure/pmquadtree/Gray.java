package cmsc420.structure.pmquadtree;

import java.awt.Color;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.TreeSet;
import java.awt.geom.Point2D.Float;

import cmsc420.structure.pmquadtree.Node;
import cmsc420.structure.City;
import cmsc420.utils.Canvas;

public class Gray extends Node{

	/** children nodes of this node */
	public Node[] children;

	/** rectangular quadrants of the children nodes */
	protected Rectangle2D.Float[] regions;

	/** origin of the rectangular bounds of this node */
	public Point2D.Float origin;

	/** origins of the rectangular bounds of each child node */
	protected Point2D.Float[] origins;

	/** width of the rectangular bounds of this node */
	public int width;

	/** height of the rectangular bounds of this node */
	public int height;

	/** half of the width of the rectangular bounds of this node */
	protected int halfWidth;

	/** half of the height of the rectangular bounds of this node */
	protected int halfHeight;
	
	public Gray(){
		super(Node.GRAY);
	}


	public Gray(Float origin, int width, int height) {
		super(Node.GRAY);

		this.origin = origin;

		children = new Node[4];
		for (int i = 0; i < 4; i++) {
			children[i] = new White(); //SingletonWhiteNode;
		}

		this.width = width;
		this.height = height;

		halfWidth = width >> 1;
		halfHeight = height >> 1;

		origins = new Point2D.Float[4];
		origins[0] = new Point2D.Float(origin.x, origin.y + halfHeight);
		origins[1] = new Point2D.Float(origin.x + halfWidth, origin.y + halfHeight);
		origins[2] = new Point2D.Float(origin.x, origin.y);
		origins[3] = new Point2D.Float(origin.x + halfWidth, origin.y);

		regions = new Rectangle2D.Float[4];
		int i = 0;
		while (i < 4) {
			regions[i] = new Rectangle2D.Float(origins[i].x, origins[i].y,
					halfWidth, halfHeight);
			i++;
		}

		/* add a cross to the drawing panel */
		if (Canvas.instance != null) {
			//canvas.addCross(getCenterX(), getCenterY(), halfWidth, Color.d);
			int cx = getCenterX();
			int cy = getCenterY();
			Canvas.instance.addLine(cx - halfWidth, cy, cx + halfWidth, cy, Color.GRAY);
			Canvas.instance.addLine(cx, cy - halfHeight, cx, cy + halfHeight, Color.GRAY);
		}
	}


	/**
	 * Gets the child node of this node according to which quadrant it falls
	 * in
	 * 
	 * @param quadrant
	 *            quadrant number (top left is 0, top right is 1, bottom
	 *            left is 2, bottom right is 3)
	 * @return child node
	 */
	public Node getChild(int quadrant) {
		if (quadrant < 0 || quadrant > 3) {
			throw new IllegalArgumentException();
		} else {
			return children[quadrant];
		}
	}

	/**
	 * Gets the rectangular region for the specified child node of this
	 * internal node.
	 * 
	 * @param quadrant
	 *            quadrant that child lies within
	 * @return rectangular region for this child node
	 */
	public Rectangle2D.Float getChildRegion(int quadrant) {
		if (quadrant < 0 || quadrant > 3) {
			throw new IllegalArgumentException();
		} else {
			return regions[quadrant];
		}
	}

	/**
	 * Gets the center X coordinate of this node's rectangular bounds.
	 * 
	 * @return center X coordinate of this node's rectangular bounds
	 */
	public int getCenterX() {
		return (int) origin.x + halfWidth;
	}

	/**
	 * Gets the center Y coordinate of this node's rectangular bounds.
	 * 
	 * @return center Y coordinate of this node's rectangular bounds
	 */
	public int getCenterY() {
		return (int) origin.y + halfHeight;
	}
	@Override
	public Node add(City city, Float origin, int width, int height) {
		final Point2D cityLocation = city.toPoint2D();
		for (int i = 0; i < 4; i++) {
			if (inBounds(cityLocation, regions[i])) {
				children[i] = children[i].add(city, origins[i], halfWidth,
						halfHeight);
			}
		}
		return this;
	}

	/**
	 * @param point
	 *            point to be checked
	 * @param rectangle
	 *            rectangular bounds the point is being checked against
	 * @return true if the point lies within the rectangular bounds, 
	 * 			  false otherwise
	 */
	private boolean inBounds(Point2D point, Rectangle2D rectangle) {
		return (point.getX() >= rectangle.getMinX() && point.getX() <= rectangle.getMaxX()
				&& point.getY() >= rectangle.getMinY() && point.getY() <= rectangle.getMaxY());
	}

	@Override
	public Node addRoad(QEdge road) {
		final Line2D.Float line = road;
		for (int i = 0; i < 4; i++) {
			if (line.intersects(regions[i])) {
				children[i] = children[i].addRoad(road);
			}
		}
		return this;
	}


	@Override
	public City getCity() {
		throw new IllegalArgumentException();
	}


	@Override
	public TreeSet<QEdge> getRoads() {
		/* should never get here, nothing to remove */
		throw new IllegalArgumentException();
	}
}

