package cmsc420.exception;

public class RoadOutOfBoundsException extends Throwable {
    /**
	 * Generated serial id
	 */
	private static final long serialVersionUID = 8355778062944660328L;

	public RoadOutOfBoundsException() {
	}

	public RoadOutOfBoundsException(String message) {
		super(message);
	}
}