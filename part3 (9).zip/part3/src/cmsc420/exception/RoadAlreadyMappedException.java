package cmsc420.exception;

public class RoadAlreadyMappedException extends Throwable {
	/**
	 * Generated serial id
	 */
	private static final long serialVersionUID = -4543305176162996623L;

	public RoadAlreadyMappedException() {
	}

	public RoadAlreadyMappedException(String message) {
		super(message);
	}
}