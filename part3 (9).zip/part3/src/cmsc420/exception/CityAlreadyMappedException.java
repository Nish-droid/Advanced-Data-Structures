package cmsc420.exception;

/**
 * Thrown if city is already in the spatial map upon attempted insertion.
 */
public class CityAlreadyMappedException extends Throwable {
	/**
	 * Generated Serial id
	 */
	private static final long serialVersionUID = -8974630029017655566L;

	public CityAlreadyMappedException() {
	}

	public CityAlreadyMappedException(String message) {
		super(message);
	}
}
