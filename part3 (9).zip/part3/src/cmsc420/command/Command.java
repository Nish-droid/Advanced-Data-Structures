///**
// * Command.java   
// *
// * @author Ruofei Du, Ben Zoller (University of Maryland, College Park), 2014
// * 
// * All rights reserved. Permission is granted for use and modification in CMSC420 
// * at the University of Maryland.
// */
//
//package cmsc420.command;
//
//import java.awt.*;
//import java.awt.geom.Point2D;
//import java.awt.geom.Rectangle2D;
//import java.io.*;
//import java.util.*;
//import java.util.Map.Entry;
//
//import org.w3c.dom.*;
//
//import cmsc420.utils.Canvas;
//import cmsc420.exception.CityAlreadyMappedException;
//import cmsc420.exception.CityOutOfBoundsException;
//import cmsc420.exception.RoadAlreadyMappedException;
//import cmsc420.exception.RoadIntersectsAnotherRoadException;
//import cmsc420.exception.RoadOutOfBoundsException;
//import cmsc420.exception.ViolatesPMRulesException;
//import cmsc420.geom.*;
//import cmsc420.sortedmap.AvlGTree;
//import cmsc420.structure.*;
//import cmsc420.structure.pmquadtree.*;
//import cmsc420.structure.pmquadtree.Node;
//import cmsc420.structure.prquadtree.PRQuadtree;
//
//
///**
// * Processes each command in the MeeshQuest program. Takes in an XML command
// * node, processes the node, and outputs the results.
// * 
// * @author Ben Zoller
// * @version 2.0, 23 Jan 2007
// */
//public class Command {
//	/** output DOM Document tree */
//	protected Document results;
//
//	/** root node of results document */
//	protected Element resultsNode;
//
//	protected int gVal;
//
//	/**
//	 * stores created cities sorted by their names (used with listCities command)
//	 */
//	protected AvlGTree<String, City> citiesByName;
//
//	/**
//	 * stores created cities sorted by their locations (used with listCities command)
//	 */
//	protected final TreeSet<City> citiesByLocation = new TreeSet<City>(new CityLocationComparator());
//
//	/** Used in map road to check if a metropole has a given pmQuadtree */
//	protected final HashMap<Metropole, PM3QuadTree> metroToPm = new HashMap<Metropole, PM3QuadTree>();
//
//	/** stores mapped cities in a spatial data structure */
//	protected final PM3QuadTree pmQuadtree = new PM3QuadTree();
//	protected final PRQuadtree prQuadtree = new PRQuadtree();
//
//	//	/** spatial width and height of the PM Quadtree */
//	//	protected int spatialWidth, spatialHeight;
//
//	protected int remoteSpatialWidth, remoteSpatialHeight, 
//	localSpatialWidth, localSpatialHeight, order;
//
//	/**
//	 * Set the DOM Document tree to send the of processed commands to.
//	 * 
//	 * Creates the root results node.
//	 * 
//	 * @param results
//	 *            DOM Document tree
//	 */
//	public void setResults(Document results) {
//		this.results = results;
//		resultsNode = results.createElement("results");
//		results.appendChild(resultsNode);
//	}
//
//	/**
//	 * Creates a command result element. Initializes the command name.
//	 * 
//	 * @param node
//	 *            the command node to be processed
//	 * @return the results node for the command
//	 */
//	private Element getCommandNode(final Element node) {
//		final Element commandNode = results.createElement("command");
//		commandNode.setAttribute("name", node.getNodeName());
//
//		if (node.getAttribute("id").compareTo("") != 0) {
//
//			final String value = node.getAttribute("id");
//
//			commandNode.setAttribute("id", value);
//		}
//		return commandNode;
//	}
//
//	/**
//	 * Processes an integer attribute for a command. Appends the parameter to
//	 * the parameters node of the results. Should not throw a number format
//	 * exception if the attribute has been defined to be an integer in the
//	 * schema and the XML has been validated beforehand.
//	 * 
//	 * @param commandNode
//	 *            node containing information about the command
//	 * @param attributeName
//	 *            integer attribute to be processed
//	 * @param parametersNode
//	 *            node to append parameter information to
//	 * @return integer attribute value
//	 */
//	private int processIntegerAttribute(final Element commandNode,
//			final String attributeName, final Element parametersNode) {
//		final String value = commandNode.getAttribute(attributeName);
//
//		if (parametersNode != null) {
//			/* add the parameters to results */
//			final Element attributeNode = results.createElement(attributeName);
//			attributeNode.setAttribute("value", value);
//			parametersNode.appendChild(attributeNode);
//		}
//
//		/* return the integer value */
//		return Integer.parseInt(value);
//	}
//
//	/**
//	 * Processes a string attribute for a command. Appends the parameter to the
//	 * parameters node of the results.
//	 * 
//	 * @param commandNode
//	 *            node containing information about the command
//	 * @param attributeName
//	 *            string attribute to be processed
//	 * @param parametersNode
//	 *            node to append parameter information to
//	 * @return string attribute value
//	 */
//	private String processStringAttribute(final Element commandNode,
//			final String attributeName, final Element parametersNode) {
//		final String value = commandNode.getAttribute(attributeName);
//
//		if (parametersNode != null) {
//			/* add parameters to results */
//			final Element attributeNode = results.createElement(attributeName);
//			attributeNode.setAttribute("value", value);
//			parametersNode.appendChild(attributeNode);
//		}
//
//		/* return the string value */
//		return value;
//	}
//
//	/**
//	 * Reports that the requested command could not be performed because of an
//	 * error. Appends information about the error to the results.
//	 * 
//	 * @param type
//	 *            type of error that occurred
//	 * @param command
//	 *            command node being processed
//	 * @param parameters
//	 *            parameters of command
//	 * @return 
//	 */
//	private Element addErrorNode(final String type, final Element command,
//			final Element parameters) {
//		final Element error = results.createElement("error");
//		error.setAttribute("type", type);
//		error.appendChild(command);
//		error.appendChild(parameters);
//		resultsNode.appendChild(error);
//		return error;
//	}
//
//	/**
//	 * Reports that a command was successfully performed. Appends the report to
//	 * the results.
//	 * 
//	 * @param command
//	 *            command not being processed
//	 * @param parameters
//	 *            parameters used by the command
//	 * @param output
//	 *            any details to be reported about the command processed
//	 */
//	private Element addSuccessNode(final Element command,
//			final Element parameters, final Element output) {
//		final Element success = results.createElement("success");
//		success.appendChild(command);
//		success.appendChild(parameters);
//		success.appendChild(output);
//		resultsNode.appendChild(success);
//		return success;
//	}
//
//	/**
//	 * Processes the commands node (root of all commands). Gets the spatial
//	 * width and height of the map and send the data to the appropriate data
//	 * structures.
//	 * 
//	 * @param node
//	 *            commands node to be processed
//	 */
//	public void processCommands(final Element node) {
//		//		spatialWidth = Integer.parseInt(node.getAttribute("spatialWidth"));
//		//		spatialHeight = Integer.parseInt(node.getAttribute("spatialHeight"));
//
//		remoteSpatialWidth = Integer.parseInt(node.getAttribute("remoteSpatialWidth"));
//		remoteSpatialHeight = Integer.parseInt(node.getAttribute("remoteSpatialHeight"));
//		localSpatialHeight = Integer.parseInt(node.getAttribute("localSpatialHeight"));
//		localSpatialWidth = Integer.parseInt(node.getAttribute("localSpatialWidth"));
//
//		gVal = Integer.parseInt(node.getAttribute("g"));
//		order = Integer.parseInt(node.getAttribute("pmOrder"));
//		citiesByName = new AvlGTree<String, City>(new Comparator<String>() {
//
//			@Override
//			public int compare(String o1, String o2) {
//				return -1*o2.compareTo(o1);
//			}
//
//		}, gVal);
//
//		/* initialize canvas */
//		Canvas.instance.setFrameSize(remoteSpatialWidth, remoteSpatialHeight);
//		/* add a rectangle to show where the bounds of the map are located */
//		Canvas.instance.addRectangle(0, 0, (remoteSpatialWidth > remoteSpatialHeight) ? remoteSpatialWidth : remoteSpatialHeight, 
//				(remoteSpatialWidth > remoteSpatialHeight) ? remoteSpatialWidth : remoteSpatialHeight, Color.WHITE, true);
//		Canvas.instance.addRectangle(0, 0, remoteSpatialWidth, remoteSpatialHeight, Color.BLACK,
//				false);
//
//		/* set Pr Quadtree range */
//		prQuadtree.setRange(remoteSpatialWidth, remoteSpatialHeight);
//	}
//
//	/**
//	 * Creates a city node containing information about a city. Appends the city
//	 * node to the passed in node.
//	 * 
//	 * @param node
//	 *            node which the city node will be appended to
//	 * @param cityNodeName
//	 *            name of city node
//	 * @param city
//	 *            city which the city node will describe
//	 */
//	private void addCityNode(final Element node, final String cityNodeName,
//			final City city) {
//		final Element cityNode = results.createElement(cityNodeName);
//		cityNode.setAttribute("name", city.getName());
//		cityNode.setAttribute("localX", Integer.toString((int) city.getLocalX()));
//		cityNode.setAttribute("localY", Integer.toString((int) city.getLocalY()));
//		cityNode.setAttribute("remoteX", Integer.toString((int) city.getRemoteX()));
//		cityNode.setAttribute("remoteY", Integer.toString((int) city.getRemoteY()));
//		cityNode.setAttribute("radius", Integer
//				.toString((int) city.getRadius()));
//		cityNode.setAttribute("color", city.getColor());
//		node.appendChild(cityNode);
//	}
//
//	private void addRoadNode(final Element node, final String roadNodeName,
//			final QEdge road) {
//		final Element roadNode = results.createElement(roadNodeName);
//		roadNode.setAttribute("end", road.getEndName());
//		roadNode.setAttribute("start", road.getStartName());
//		node.appendChild(roadNode);
//	}
//
//	private void addRoadNode(final Element node, final QEdge road) {
//		addRoadNode(node, "road", road);
//	}
//
//	/**
//	 * Processes a createCity command. Creates a city in the dictionary (Note:
//	 * does not map the city). An error occurs if a city with that name or
//	 * location is already in the dictionary.
//	 * 
//	 * @param node
//	 *            createCity node to be processed
//	 */
//	public void processCreateCity(final Element node) {
//		final Element commandNode = getCommandNode(node);
//		final Element parametersNode = results.createElement("parameters");
//
//		final String name = processStringAttribute(node, "name", parametersNode);
//		final int localX = processIntegerAttribute(node, "localX", parametersNode);
//		final int localY = processIntegerAttribute(node, "localY", parametersNode);
//		final int remoteX = processIntegerAttribute(node, "remoteX", parametersNode);
//		final int remoteY = processIntegerAttribute(node, "remoteY", parametersNode);
//		final int radius = processIntegerAttribute(node, "radius", parametersNode);
//		final String color = processStringAttribute(node, "color", parametersNode);
//
//		/* create the city */
//		final City city = new City(name, localX, localY, remoteX, remoteY, radius, color);
//
//		if (citiesByLocation.contains(city)) {
//			addErrorNode("duplicateCityCoordinates", commandNode,
//					parametersNode);
//		} else if (citiesByName.containsKey(name)) {
//			addErrorNode("duplicateCityName", commandNode, 
//					parametersNode);
//		} else {
//			final Element outputNode = results.createElement("output");
//
//			/* add city to dictionary */
//			citiesByName.put(name, city);
//			citiesByLocation.add(city);
//
//			/* add success node to results */
//			addSuccessNode(commandNode, parametersNode, outputNode);
//		}
//	}
//
//	/**
//	 * Deletes city from the dictionary
//	 * @param commandNode
//	 * 					deleteCity node to be processed
//	 */
//	public void processDeleteCity(Element node) {
//		// TODO Auto-generated method stub
//		final Element commandNode = getCommandNode(node);
//		final Element parametersNode = results.createElement("parameters");
//		final String name = processStringAttribute(node, "name", parametersNode);
//
//		if (!citiesByName.containsKey(name)) {
//			/* city with name does not exist */
//			addErrorNode("cityDoesNotExist", commandNode, parametersNode);
//		} 
//	}
//
//	/**
//	 * Clears all the data structures do there are not cities or roads in
//	 * existence in the dictionary or on the map.
//	 * 
//	 * @param node
//	 *            clearAll node to be processed
//	 */
//	public void processClearAll(final Element node) {
//		final Element commandNode = getCommandNode(node);
//		final Element parametersNode = results.createElement("parameters");
//		final Element outputNode = results.createElement("output");
//
//		/* clear data structures */
//		citiesByName.clear();
//		citiesByLocation.clear();
//		pmQuadtree.clear();
//
//		/* clear canvas */
//		Canvas.instance.clear();
//		/* add a rectangle to show where the bounds of the map are located */
//		Canvas.instance.addRectangle(0, 0, remoteSpatialWidth, remoteSpatialHeight, Color.BLACK,
//				false);
//
//		/* add success node to results */
//		addSuccessNode(commandNode, parametersNode, outputNode);
//	}
//
//	/**
//	 * Lists all the cities, either by name or by location.
//	 * 
//	 * @param node
//	 *            listCities node to be processed
//	 */
//	public void processListCities(final Element node) {
//		final Element commandNode = getCommandNode(node);
//		final Element parametersNode = results.createElement("parameters");
//		final String sortBy = processStringAttribute(node, "sortBy",
//				parametersNode);
//
//		if (citiesByName.isEmpty()) {
//			addErrorNode("noCitiesToList", commandNode, parametersNode);
//		} else {
//			final Element outputNode = results.createElement("output");
//			final Element cityListNode = results.createElement("cityList");
//
//			Collection<City> cityCollection = null;
//			if (sortBy.equals("name")) {
//				cityCollection = citiesByName.values();
//			} else if (sortBy.equals("coordinate")) {
//				cityCollection = citiesByLocation;
//			} else {
//				/* XML validator failed */
//				System.exit(-1);
//			}
//
//			for (City c : cityCollection) {
//				addCityNode(cityListNode, "city", c);
//			}
//			outputNode.appendChild(cityListNode);
//
//			/* add success node to results */
//			addSuccessNode(commandNode, parametersNode, outputNode);
//		}
//	}
//
//
//	/**
//	 * Processes Avl tree and print it based on PMQuadtree
//	 * @param node
//	 */
//	public void processAvlTree(Element node) {
//		final Element commandNode = getCommandNode(node);
//		final Element parametersNode = results.createElement("parameters");
//		final Element outputNode = results.createElement("output");
//
//		Element xmlNode = results.createElement("AvlGTree");
//
//		if (!citiesByName.isEmpty()) {
//			xmlNode.setAttribute("cardinality", Integer.toString(citiesByName.size())); //Change the number
//			xmlNode.setAttribute("height", Integer.toString(citiesByName.rootHeight())); //Change the height
//			xmlNode.setAttribute("maxImbalance", Integer.toString(gVal));  //Gvalue
//
//			outputNode.appendChild(xmlNode);
//
//			citiesByName.printAvlGTree(xmlNode, results, citiesByName);
//
//			addSuccessNode(commandNode, parametersNode, outputNode);
//		} else {
//			addErrorNode("emptyTree", commandNode, parametersNode);
//		}
//	}
//
//	/**
//	 * Prints out the structure of the PR Quadtree in a human-readable format.
//	 * 
//	 * @param node
//	 *            printPMQuadtree command to be processed
//	 */
//	public void processPrintPMQuadtree(final Element node) {
//		final Element commandNode = getCommandNode(node);
//		final Element parametersNode = results.createElement("parameters");
//		final Element outputNode = results.createElement("output");
//
//		processIntegerAttribute(node, "remoteX", parametersNode);
//		processIntegerAttribute(node, "remoteY", parametersNode);
//
//
//		if (pmQuadtree.isEmpty()) {
//			/* empty PMQuadtree */
//			addErrorNode("mapIsEmpty", commandNode, parametersNode);
//		} else {
//			/* print PMQuadtree */
//			final Element quadtreeNode = results.createElement("quadtree");
//			/* order is 3 because that is only what we need to know */
//			quadtreeNode.setAttribute("order", "3");
//			printPMQuadtreeHelper(pmQuadtree.getRoot(), quadtreeNode);
//
//			outputNode.appendChild(quadtreeNode);
//
//			/* add success node to results */
//			addSuccessNode(commandNode, parametersNode, outputNode);
//		}
//	}
//
//	/**
//	 * Traverses each node of the PMQuadtree.
//	 * 
//	 * @param currentNode
//	 *            PMQuadtree node being printed
//	 * @param quadNode
//	 *            quad node representing the current PMQuadtree node
//	 */
//	private void printPMQuadtreeHelper(final Node currentNode,
//			final Element quadNode) {
//
//		if (currentNode.getType() == Node.WHITE) {
//			Element white = results.createElement("white");
//			quadNode.appendChild(white);
//		} else {
//			if (currentNode.getType() == Node.BLACK) {
//				/* leaf node */
//				final Black currentBlack = (Black) currentNode;
//				int roadSize = currentBlack.getRoadsSize();
//				final Element black = results.createElement("black");
//
//				if (currentBlack.hasCity()){
//					roadSize++;
//					String title = "city";
//					if (pmQuadtree.isInIso(currentBlack.getCity())){
//						title = "isolatedCity";
//					}
//
//					final Element city = results.createElement(title);
//					city.setAttribute("name", currentBlack.getCity().getName());
//					city.setAttribute("color", currentBlack.getCity().getColor());
//					city.setAttribute("localX", Integer.toString((int) currentBlack.getCity().localPt.getX()));
//					city.setAttribute("localY", Integer.toString((int) currentBlack.getCity().localPt.getY()));
//					city.setAttribute("remoteX", Integer.toString((int) currentBlack.getCity().remotePt.getX()));
//					city.setAttribute("remoteY", Integer.toString((int) currentBlack.getCity().remotePt.getY()));
//					city.setAttribute("radius", Integer.toString((int) currentBlack.getCity().getRadius()));
//
//					black.appendChild(city);
//				}
//
//				black.setAttribute("cardinality", Integer.toString(roadSize));
//
//				if (currentBlack.getRoadsSize() > 0) {
//					for(QEdge edge : currentBlack.getRoads()) {
//						final Element road = results.createElement("road");
//						road.setAttribute("end", edge.getEndName());
//						road.setAttribute("start", edge.getStartName());
//						black.appendChild(road);
//					}
//				}
//				quadNode.appendChild(black);
//			} else {
//				/* internal node */
//				final Gray currentGray = (Gray) currentNode;
//				final Element gray = results.createElement("gray");
//				gray.setAttribute("x", Integer.toString((int) currentGray.getCenterX()));
//				gray.setAttribute("y", Integer.toString((int) currentGray.getCenterY()));
//				for (int i = 0; i < 4; i++) {
//					printPMQuadtreeHelper(currentGray.getChild(i), gray);
//				}
//				quadNode.appendChild(gray);
//			}
//		}
//	}
//
//
//	/**
//	 * Processes Mst minimum spanning tree, just like shortestPath
//	 * @param commandNode
//	 */
//	public void processMst(Element commandNode) {
//		// TODO Auto-generated method stub
//
//	}
//
//
//	/**
//	 * Maps a road in the spatial map
//	 * @param node
//	 * 			  map road command to be processed
//	 */
//	public void processMapRoad(final Element node) {
//		final Element commandNode = getCommandNode(node);
//		final Element parametersNode = results.createElement("parameters");
//		final Element outputNode = results.createElement("output");
//
//		final String start = processStringAttribute(node, "start", parametersNode);
//		final String end = processStringAttribute(node, "end", parametersNode);		
//
//		final City startCity = citiesByName.get(start);
//		final City endCity = citiesByName.get(end);
//
//		Metropole m = null;
//		PM3QuadTree pmQuadtree = new PM3QuadTree();
//		pmQuadtree.setRange(localSpatialWidth, localSpatialHeight);
//		pmQuadtree.setOrder(order);
//
//		if (!citiesByName.containsKey(start)) {
//			addErrorNode("startPointDoesNotExist", commandNode, parametersNode);
//		} else if (!citiesByName.containsKey(end)) {
//			addErrorNode("endPointDoesNotExist", commandNode, parametersNode);
//		} else if (start.equals(end)) {
//			addErrorNode("startEqualsEnd", commandNode, parametersNode);
//		} else if (startCity.getRemoteX() != endCity.getRemoteX() ||
//				startCity.getRemoteY() != endCity.getRemoteY()){
//			addErrorNode("roadNotInOneMetropole", commandNode, parametersNode);
//		} else if (startCity.getRemoteX() < 0 || startCity.getRemoteX() >= remoteSpatialWidth 
//				|| startCity.getRemoteY() < 0 || startCity.getRemoteY() >= remoteSpatialHeight ||
//				endCity.getRemoteX() < 0 || endCity.getRemoteX() >= remoteSpatialWidth 
//				|| endCity.getRemoteY() < 0 || endCity.getRemoteY() >= remoteSpatialHeight) {
//			addErrorNode("roadOutOfBounds", commandNode, parametersNode);
//		} else {
//			m = new Metropole(startCity.getRemoteX(), startCity.getRemoteY());
//			//System.out.println("metropole: " + m==null);
//			if(!prQuadtree.contains(m)) {
//				prQuadtree.add(m);
//				pmQuadtree.setRange(localSpatialWidth, localSpatialHeight);
//				pmQuadtree.setOrder(order);
//				pmQuadtree.addRoad(startCity, endCity);
//
//				metroToPm.put(m, pmQuadtree);
//			} else {
//				pmQuadtree = metroToPm.get(m);
//				pmQuadtree.addRoad(startCity, endCity);
//			}
//
//			if (pmQuadtree.contains(startCity.getName())) {
//				Canvas.instance.addPoint(startCity.getName(), startCity.getLocalX(), 
//						startCity.getLocalY(), Color.BLACK);
//			}
//			if (pmQuadtree.contains(endCity.getName())) {
//				Canvas.instance.addPoint(endCity.getName(), endCity.getLocalX(), 
//						endCity.getLocalY(), Color.BLACK);
//			}
//
//			Canvas.instance.addLine(startCity.getLocalX(), startCity.getLocalY(),
//					endCity.getLocalX(), endCity.getLocalY(), Color.BLACK);
//			final Element createdRoad = results.createElement("roadCreated");
//			createdRoad.setAttribute("start", startCity.getName());
//			createdRoad.setAttribute("end", endCity.getName());
//			outputNode.appendChild(createdRoad);
//
//			addSuccessNode(commandNode, parametersNode, outputNode);
//		}
//	}
//
//
//	/**
//	 * unMaps road from the spatialMap
//	 * @param commandNode
//	 * 					UnMap command to be processed
//	 */
//	public void processUnmapRoad(Element commandNode) {
//		// TODO Auto-generated method stub
//
//	}
//
//	/**
//	 * Map terminal in the spatial map
//	 * @param commandNode
//	 */
//	public void processMapTerminal(Element commandNode) {
//		// TODO Auto-generated method stub
//
//	}
//
//	/**
//	 * unMaps terminal in the spatial map
//	 * @param commandNode
//	 */
//	public void processUnMapTerminal(Element commandNode) {
//		// TODO Auto-generated method stub
//
//	}
//
//	/**
//	 * Maps airport in the spatial Map
//	 * @param commandNode
//	 */
//	public void processMapAirport(Element node) {
//		// TODO Auto-generated method stub
//		final Element commandNode = getCommandNode(node);
//		final Element parametersNode = results.createElement("parameters");
//		final Element outputNode = results.createElement("output");
//
//		final String airportName = processStringAttribute(node, "name", parametersNode);
//		final String localX = processStringAttribute(node, "localX", parametersNode);
//		final String localY = processStringAttribute(node, "localY", parametersNode);		
//		final String remoteX = processStringAttribute(node, "remoteX", parametersNode);
//		final String remoteY = processStringAttribute(node, "remoteY", parametersNode);		
//		final String terminalName = processStringAttribute(node, "terminalName", parametersNode);		
//		final String terminalX = processStringAttribute(node, "terminalX", parametersNode);
//		final String terminalY = processStringAttribute(node, "terminalY", parametersNode);		
//		final String terminalCity = processStringAttribute(node, "terminalCity", parametersNode);
//
//		//final String id = pocessStringAttribute(node, "id", parametersNode);		
//
//		addSuccessNode(commandNode, parametersNode, outputNode);
//
//	}
//
//	/**
//	 * Maps airport in the spatial Map
//	 * @param commandNode
//	 */
//	public void processUnMapAirport(Element node) {
//		// TODO Auto-generated method stub
//		final Element commandNode = getCommandNode(node);
//		final Element parametersNode = results.createElement("parameters");
//		final Element outputNode = results.createElement("output");
//
//		final String airportName = processStringAttribute(node, "name", parametersNode);
//		final String localX = processStringAttribute(node, "localX", parametersNode);
//		final String localY = processStringAttribute(node, "localY", parametersNode);		
//		final String remoteX = processStringAttribute(node, "remoteX", parametersNode);
//		final String remoteY = processStringAttribute(node, "remoteY", parametersNode);		
//		final String terminalName = processStringAttribute(node, "terminalName", parametersNode);		
//		final String terminalX = processStringAttribute(node, "terminalX", parametersNode);
//		final String terminalY = processStringAttribute(node, "terminalY", parametersNode);		
//		final String terminalCity = processStringAttribute(node, "terminalCity", parametersNode);
//
//		//final String id = pocessStringAttribute(node, "id", parametersNode);		
//
//		addSuccessNode(commandNode, parametersNode, outputNode);
//
//	}
//
//	/**
//	 * Processes a saveMap command. Saves the graphical map to a given file.
//	 * 
//	 * @param node
//	 *            saveMap command to be processed
//	 * @throws IOException
//	 *             problem accessing the image file
//	 */
//	public void processSaveMap(final Element node) {
//		final Element commandNode = getCommandNode(node);
//		final Element parametersNode = results.createElement("parameters");
//
//		final String name = processStringAttribute(node, "name", parametersNode);
//
//		final Element outputNode = results.createElement("output");
//
//		/* save canvas to '<name>.png' */
//		//Canvas.instance.save(name);
//
//		/* add success node to results */
//		addSuccessNode(commandNode, parametersNode, outputNode);
//	}
//
//
//	/**
//	 * Finds the mapped cities within the range of a given point.
//	 * 
//	 * @param node
//	 *            rangeCities command to be processed
//	 * @throws IOException
//	 */
//	public void processGlobalRangeCities(final Element node) {
//		final Element commandNode = getCommandNode(node);
//		final Element parametersNode = results.createElement("parameters");
//		final Element outputNode = results.createElement("output");
//
//		final TreeSet<City> citiesInRange = new TreeSet<City>(new CityNameComparator());
//
//		/* extract values from command */
//		final int x = processIntegerAttribute(node, "x", parametersNode);
//		final int y = processIntegerAttribute(node, "y", parametersNode);
//		final int radius = processIntegerAttribute(node, "radius",
//				parametersNode);
//
//		String pathFile = "";
//		if (node.getAttribute("saveMap").compareTo("") != 0) {
//			pathFile = processStringAttribute(node, "saveMap", parametersNode);
//		}
//
//		/* get cities within range */
//		final Point2D.Double point = new Point2D.Double(x, y);
//		rangeCitiesHelper(point, radius, pmQuadtree.getRoot(), citiesInRange);
//
//		/* print out cities within range */
//		if (citiesInRange.isEmpty()) {
//			addErrorNode("noCitiesExistInRange", commandNode, parametersNode);
//		} else {
//			/* get city list */
//			final Element cityListNode = results.createElement("cityList");
//			for (City city : citiesInRange) {
//				addCityNode(cityListNode, "city", city);
//			}
//			outputNode.appendChild(cityListNode);
//
//			/* add success node to results */
//			addSuccessNode(commandNode, parametersNode, outputNode);
//
//			if (pathFile.compareTo("") != 0) {
//				if(radius != 0) 
//					Canvas.instance.addCircle(x, y, radius, Color.BLUE, false);
//				//Canvas.instance.save(pathFile);
//				if(radius != 0) 
//					Canvas.instance.removeCircle(x, y, radius, Color.BLUE, false);
//			}
//		}
//	}
//
//
//	/**
//	 * Determines if any roads within the PMQuadtree are within 
//	 * the radius of a given point.
//	 * 
//	 * @param point
//	 *            point from which the cities are measured
//	 * @param radius
//	 *            radius from which the given points are measured
//	 * @param node
//	 *            PM3Quadtree node being examined
//	 * @param citiesInRange
//	 *            a list of cities found to be in range
//	 */
//	private void rangeCitiesHelper(final Point2D.Double point,
//			final int radius, final Node node, final TreeSet<City> citiesInRange) {
//
//		if (node.getType() == Node.BLACK && ((Black) node).hasCity()) {
//			final Black black = (Black) node;
//			final double distance = point.distance(black.getCity().toPoint2D());
//			if (distance <= radius) {
//				/* city is in range */
//				final City city = black.getCity();
//				citiesInRange.add(city);
//			}
//		} else if (node.getType() == Node.GRAY) {
//			/* check each quadrant of internal node */
//			final Gray internal = (Gray) node;
//
//			final Circle2D.Double circle = new Circle2D.Double(point, radius);
//			for (int i = 0; i < 4; i++) {
//				if (pmQuadtree.intersects(circle, internal.getChildRegion(i))) {
//					rangeCitiesHelper(point, radius, internal.getChild(i),
//							citiesInRange);
//				}
//			}
//		}
//	}
//
//	/**
//	 * Findsd nearest Airport in the spatial map
//	 * @param commandNode
//	 */
//	public void processNearestAirport(Element commandNode) {
//		// TODO Auto-generated method stub
//
//	}
//
//	/**
//	 * Finds the nearest city to a given point.
//	 * 
//	 * @param node
//	 *            nearestCity command being processed
//	 */
//	public void processNearestCity(Element node) {
//		final Element commandNode = getCommandNode(node);
//		final Element parametersNode = results.createElement("parameters");
//		final Element outputNode = results.createElement("output");
//
//		/* extract attribute values from command */
//		final int locX = processIntegerAttribute(node, "localX", parametersNode);
//		final int locY = processIntegerAttribute(node, "localY", parametersNode);
//		final int remX = processIntegerAttribute(node, "remoteX", parametersNode);
//		final int remY = processIntegerAttribute(node, "remoteY", parametersNode);
//
//		final Point2D.Float point = new Point2D.Float(locX, locY);
//
//		if (citiesByName.size() <= 0) {
//			addErrorNode("cityNotFound", commandNode, parametersNode);
//		} else if (pmQuadtree.hasCites() && pmQuadtree.getRoot().getType() == Node.BLACK) {
//			addErrorNode("cityNotFound", commandNode, parametersNode);
//		} else if (pmQuadtree.getRoot().getType() == Node.BLACK && pmQuadtree.hasCites() 
//				&& pmQuadtree.isInIso(pmQuadtree.getRoot().getCity())) {
//			addErrorNode("cityNotFound", commandNode, parametersNode);
//		} 
//		else {
//
//			if (pmQuadtree.getRoot().getType()==Node.WHITE) {
//				addErrorNode("cityNotFound", commandNode, parametersNode);
//				return;
//			}
//			City n = nearestCityHelper(pmQuadtree.getRoot(), point);
//
//			if (n == null) {
//				addErrorNode("cityNotFound", commandNode, parametersNode);
//				return;
//			}
//
//			addCityNode(outputNode, "city", n);
//
//			addSuccessNode(commandNode, parametersNode, outputNode);
//		}
//	}
//
//	/**
//	 * @param root root of the PMQuadtree
//	 * @param point point to calculate the distances from
//	 */
//	private City nearestCityHelper(Node root, Point2D.Float point) {
//		PriorityQueue<QuadrantDistance> q = new PriorityQueue<QuadrantDistance>();
//		Node currNode = root;
//		while (currNode.getType() != Node.BLACK) {
//			if (currNode.getType() != Node.WHITE) {
//				Gray g = (Gray) currNode;
//				for (int i = 0; i < 4; i++) {
//					Node kid = g.children[i];
//
//					if (kid.getType() == Node.GRAY || 
//							(kid.getType() == Node.BLACK && ((Black) kid).hasCity() &&
//							!pmQuadtree.isInIso(((Black) kid).getCity()))) {
//						QuadrantDistance test = new QuadrantDistance(kid, point);
//						if (!q.contains(test))
//							q.add(test);
//					}
//				}
//			}
//			if(!q.isEmpty()) currNode = q.remove().quadtreeNode;
//			else return null;
//		}
//		return ((Black) currNode).getCity();
//	}
//
//
//	/**
//	 * Distance between a line
//	 * @author
//	 */
//
//	class QuadrantDistance implements Comparable<QuadrantDistance> {
//		public Node quadtreeNode;
//		private double distance;
//
//		public QuadrantDistance(Node node, Point2D.Float pt) {
//			quadtreeNode = node;
//			if (node.getType() == Node.GRAY) {
//				Gray gray = (Gray) node;
//				distance = Shape2DDistanceCalculator.distance(pt, 
//						new Rectangle2D.Float(gray.origin.x, gray.origin.y, gray.width, gray.height));
//			} else if (node.getType() == Node.BLACK) {
//				Black leaf = (Black) node;
//				distance = pt.distance(leaf.getCity().localPt);
//			} else {
//				throw new IllegalArgumentException("Only leaf or internal node can be passed in");
//			}
//		}
//
//		public int compareTo(QuadrantDistance qd) {
//			if (distance < qd.distance) {
//				return -1;
//			} else if (distance > qd.distance) {
//				return 1;
//			} else {
//				if (quadtreeNode.getType() != qd.quadtreeNode.getType()) {
//					if (quadtreeNode.getType() == Node.GRAY) {
//						return -1;
//					} else {
//						return 1;
//					}
//				} else if (quadtreeNode.getType() == Node.BLACK) {
//					// both are black
//					return ((Black) qd.quadtreeNode).getCity().getName().compareTo(
//							((Black) quadtreeNode).getCity().getName());
//				} else {
//					// both are gray
//					return 0;
//				}
//			}
//		}
//	}
//
//
//
//}


/**
 * Command.java   
 *
 * @author Ruofei Du, Ben Zoller (University of Maryland, College Park), 2014
 * 
 * All rights reserved. Permission is granted for use and modification in CMSC420 
 * at the University of Maryland.
 */

package cmsc420.command;

import java.awt.*;
import java.awt.geom.Arc2D;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Float;
import java.awt.geom.Rectangle2D;
import java.io.*;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.*;
import java.util.Map.Entry;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.w3c.dom.*;

import cmsc420.utils.Canvas;
import cmsc420.xml.XmlUtility;
import cmsc420.drawing.CanvasPlus;
import cmsc420.exception.CityAlreadyMappedException;
import cmsc420.exception.CityOutOfBoundsException;
import cmsc420.exception.RoadAlreadyMappedException;
import cmsc420.exception.RoadOutOfBoundsException;
import cmsc420.geom.*;
import cmsc420.sortedmap.AvlGTree;
import cmsc420.structure.*;
import cmsc420.structure.pmquadtree.*;
import cmsc420.structure.pmquadtree.Node;


/**
 * Processes each command in the MeeshQuest program. Takes in an XML command
 * node, processes the node, and outputs the results.
 * 
 * @author Ben Zoller
 * @version 2.0, 23 Jan 2007
 */
public class Command {
	/** output DOM Document tree */
	protected Document results;

	/** root node of results document */
	protected Element resultsNode;

	protected int gVal;

	/**
	 * stores created cities sorted by their names (used with listCities command)
	 */
	protected AvlGTree<String, City> citiesByName;

	/**
	 * stores created Airprots sorted by their names (used with listCities command)
	 */
	protected TreeMap<String, City> airportsByName;

	protected TreeMap<String, City> terminalsByName;
	
	/**
	 * stores created cities sorted by their locations (used with listCities command)
	 */
	protected final TreeSet<City> citiesByLocation = new TreeSet<City>(new CityLocationComparator());

	/** stores mapped cities in a spatial data structure */
	//protected final PRQuadtree prQuadtree = new PRQuadtree();

	protected final PM3QuadTree pmQuadtree = new PM3QuadTree();

	/** spatial width and height of the PM Quadtree */
	protected int spatialWidth, spatialHeight;

	private int remoteSpatialWidth;

	private int remoteSpatialHeight;

	private int localSpatialWidth;

	private int localSpatialHeight;

	private int order;

	/**
	 * Set the DOM Document tree to send the of processed commands to.
	 * 
	 * Creates the root results node.
	 * 
	 * @param results
	 *            DOM Document tree
	 */
	public void setResults(Document results) {
		this.results = results;
		resultsNode = results.createElement("results");
		results.appendChild(resultsNode);
	}

	/**
	 * Creates a command result element. Initializes the command name.
	 * 
	 * @param node
	 *            the command node to be processed
	 * @return the results node for the command
	 */
	private Element getCommandNode(final Element node) {
		final Element commandNode = results.createElement("command");
		commandNode.setAttribute("name", node.getNodeName());

		if (node.getAttribute("id").compareTo("") != 0) {

			final String value = node.getAttribute("id");

			commandNode.setAttribute("id", value);
		}
		return commandNode;
	}

	/**
	 * Processes an integer attribute for a command. Appends the parameter to
	 * the parameters node of the results. Should not throw a number format
	 * exception if the attribute has been defined to be an integer in the
	 * schema and the XML has been validated beforehand.
	 * 
	 * @param commandNode
	 *            node containing information about the command
	 * @param attributeName
	 *            integer attribute to be processed
	 * @param parametersNode
	 *            node to append parameter information to
	 * @return integer attribute value
	 */
	private int processIntegerAttribute(final Element commandNode,
			final String attributeName, final Element parametersNode) {
		final String value = commandNode.getAttribute(attributeName);

		if (parametersNode != null) {
			/* add the parameters to results */
			final Element attributeNode = results.createElement(attributeName);
			attributeNode.setAttribute("value", value);
			parametersNode.appendChild(attributeNode);
		}

		/* return the integer value */
		return Integer.parseInt(value);
	}

	/**
	 * Processes a string attribute for a command. Appends the parameter to the
	 * parameters node of the results.
	 * 
	 * @param commandNode
	 *            node containing information about the command
	 * @param attributeName
	 *            string attribute to be processed
	 * @param parametersNode
	 *            node to append parameter information to
	 * @return string attribute value
	 */
	private String processStringAttribute(final Element commandNode,
			final String attributeName, final Element parametersNode) {
		final String value = commandNode.getAttribute(attributeName);

		if (parametersNode != null) {
			/* add parameters to results */
			final Element attributeNode = results.createElement(attributeName);
			attributeNode.setAttribute("value", value);
			parametersNode.appendChild(attributeNode);
		}

		/* return the string value */
		return value;
	}

	/**
	 * Reports that the requested command could not be performed because of an
	 * error. Appends information about the error to the results.
	 * 
	 * @param type
	 *            type of error that occurred
	 * @param command
	 *            command node being processed
	 * @param parameters
	 *            parameters of command
	 * @return 
	 */
	private Element addErrorNode(final String type, final Element command,
			final Element parameters) {
		final Element error = results.createElement("error");
		error.setAttribute("type", type);
		error.appendChild(command);
		error.appendChild(parameters);
		resultsNode.appendChild(error);
		return error;
	}

	/**
	 * Reports that a command was successfully performed. Appends the report to
	 * the results.
	 * 
	 * @param command
	 *            command not being processed
	 * @param parameters
	 *            parameters used by the command
	 * @param output
	 *            any details to be reported about the command processed
	 */
	private Element addSuccessNode(final Element command,
			final Element parameters, final Element output) {
		final Element success = results.createElement("success");
		success.appendChild(command);
		success.appendChild(parameters);
		success.appendChild(output);
		resultsNode.appendChild(success);
		return success;
	}

	/**
	 * Processes the commands node (root of all commands). Gets the spatial
	 * width and height of the map and send the data to the appropriate data
	 * structures.
	 * 
	 * @param node
	 *            commands node to be processed
	 */
	public void processCommands(final Element node) {
		//		spatialWidth = Integer.parseInt(node.getAttribute("spatialWidth"));
		//		spatialHeight = Integer.parseInt(node.getAttribute("spatialHeight"));

		remoteSpatialWidth = Integer.parseInt(node.getAttribute("remoteSpatialWidth"));
		remoteSpatialHeight = Integer.parseInt(node.getAttribute("remoteSpatialHeight"));
		spatialHeight = Integer.parseInt(node.getAttribute("localSpatialHeight"));
		spatialWidth = Integer.parseInt(node.getAttribute("localSpatialWidth"));

		gVal = Integer.parseInt(node.getAttribute("g"));
		order = Integer.parseInt(node.getAttribute("pmOrder"));
		citiesByName = new AvlGTree<String, City>(new Comparator<String>() {

			@Override
			public int compare(String o1, String o2) {
				return o2.compareTo(o1);
			}

		}, gVal);
		
		airportsByName = new TreeMap<String, City>(new Comparator<String>() {

			@Override
			public int compare(String o1, String o2) {
				return o2.compareTo(o1);
			}

		});

		terminalsByName = new TreeMap<String, City>(new Comparator<String>() {

			@Override
			public int compare(String o1, String o2) {
				return o2.compareTo(o1);
			}

		});
		
		/* initialize canvas */
		Canvas.instance.setFrameSize(remoteSpatialWidth, remoteSpatialHeight);
		/* add a rectangle to show where the bounds of the map are located */
		Canvas.instance.addRectangle(0, 0, (remoteSpatialWidth > remoteSpatialHeight) ? remoteSpatialWidth : remoteSpatialHeight, 
				(remoteSpatialWidth > remoteSpatialHeight) ? remoteSpatialWidth : remoteSpatialHeight, Color.WHITE, true);
		Canvas.instance.addRectangle(0, 0, remoteSpatialWidth, remoteSpatialHeight, Color.BLACK,
				false);

		/* set Pr Quadtree range */
		pmQuadtree.setRange(remoteSpatialWidth, remoteSpatialHeight);
	}
	/**
	 * Processes a createCity command. Creates a city in the dictionary (Note:
	 * does not map the city). An error occurs if a city with that name or
	 * location is already in the dictionary.
	 * 
	 * @param node
	 *            createCity node to be processed
	 */
	public void processCreateCity(final Element node) {
		final Element commandNode = getCommandNode(node);
		final Element parametersNode = results.createElement("parameters");

		final String name = processStringAttribute(node, "name", parametersNode);
		final int localX = processIntegerAttribute(node, "localX", parametersNode);
		final int localY = processIntegerAttribute(node, "localY", parametersNode);
		final int remoteX = processIntegerAttribute(node, "remoteX", parametersNode);
		final int remoteY = processIntegerAttribute(node, "remoteY", parametersNode);
		final int radius = processIntegerAttribute(node, "radius",
				parametersNode);
		final String color = processStringAttribute(node, "color",
				parametersNode);

		/* create the city */
		final City city = new City(name, localX, localY, remoteX, remoteY, radius, color);

		if (citiesByLocation.contains(city)) {
			addErrorNode("duplicateCityCoordinates", commandNode,
					parametersNode);
		} else if (citiesByName.containsKey(name)) {
			addErrorNode("duplicateCityName", commandNode, 
					parametersNode);
		} else {
			final Element outputNode = results.createElement("output");

			/* add city to dictionary */
			citiesByName.put(name, city);
			citiesByLocation.add(city);

			/* add success node to results */
			addSuccessNode(commandNode, parametersNode, outputNode);
		}
	}

	/**
	 * Clears all the data structures do there are not cities or roads in
	 * existence in the dictionary or on the map.
	 * 
	 * @param node
	 *            clearAll node to be processed
	 */
	public void processClearAll(final Element node) {
		final Element commandNode = getCommandNode(node);
		final Element parametersNode = results.createElement("parameters");
		final Element outputNode = results.createElement("output");

		/* clear data structures */
		citiesByName.clear();
		citiesByLocation.clear();
		pmQuadtree.clear();

		/* clear canvas */
		Canvas.instance.clear();
		/* add a rectangle to show where the bounds of the map are located */
		Canvas.instance.addRectangle(0, 0, spatialWidth, spatialHeight, Color.BLACK,
				false);

		/* add success node to results */
		addSuccessNode(commandNode, parametersNode, outputNode);
	}

	/**
	 * Lists all the cities, either by name or by location.
	 * 
	 * @param node
	 *            listCities node to be processed
	 */
	public void processListCities(final Element node) {
		final Element commandNode = getCommandNode(node);
		final Element parametersNode = results.createElement("parameters");
		final String sortBy = processStringAttribute(node, "sortBy",
				parametersNode);

		if (citiesByName.isEmpty()) {
			addErrorNode("noCitiesToList", commandNode, parametersNode);
		} else {
			final Element outputNode = results.createElement("output");
			final Element cityListNode = results.createElement("cityList");

			Collection<City> cityCollection = null;
			if (sortBy.equals("name")) {
				cityCollection = citiesByName.values();
			} else if (sortBy.equals("coordinate")) {
				cityCollection = citiesByLocation;
			} else {
				/* XML validator failed */
				System.exit(-1);
			}

			for (City c : cityCollection) {
				addCityNode(cityListNode, "city", c);
			}
			outputNode.appendChild(cityListNode);

			/* add success node to results */
			addSuccessNode(commandNode, parametersNode, outputNode);
		}
	}

	/**
	 * Creates a city node containing information about a city. Appends the city
	 * node to the passed in node.
	 * 
	 * @param node
	 *            node which the city node will be appended to
	 * @param cityNodeName
	 *            name of city node
	 * @param city
	 *            city which the city node will describe
	 */
	private void addCityNode(final Element node, final String cityNodeName,
			final City city) {
		final Element cityNode = results.createElement(cityNodeName);
		cityNode.setAttribute("name", city.getName());
		cityNode.setAttribute("localX", Integer.toString((int) city.getLocalX()));
		cityNode.setAttribute("localY", Integer.toString((int) city.getLocalY()));
		cityNode.setAttribute("remoteX", Integer.toString((int) city.getRemoteX()));
		cityNode.setAttribute("remoteY", Integer.toString((int) city.getRemoteY()));
		cityNode.setAttribute("radius", Integer
				.toString((int) city.getRadius()));
		cityNode.setAttribute("color", city.getColor());
		node.appendChild(cityNode);
	}

	private void addRoadNode(final Element node, final String roadNodeName,
			final QEdge road) {
		final Element roadNode = results.createElement(roadNodeName);
		roadNode.setAttribute("end", road.getEndName());
		roadNode.setAttribute("start", road.getStartName());
		node.appendChild(roadNode);
	}

	private void addRoadNode(final Element node, final QEdge road) {
		addRoadNode(node, "road", road);
	}

	/**
	 * Maps a city to the spatial map.
	 * 
	 * @param node
	 *            mapCity command node to be processed
	 */
	public void processMapCity(final Element node) {
		final Element commandNode = getCommandNode(node);
		final Element parametersNode = results.createElement("parameters");

		final String name = processStringAttribute(node, "name", parametersNode);

		final Element outputNode = results.createElement("output");

		if (!citiesByName.containsKey(name)) {
			addErrorNode("nameNotInDictionary", commandNode, parametersNode);
		} else if (pmQuadtree.contains(name)) {
			addErrorNode("cityAlreadyMapped", commandNode, parametersNode);
		} else {
			City city = citiesByName.get(name);
			try {
				/* insert city into PM Quadtree */
				pmQuadtree.add(city);
				pmQuadtree.addIso(city.getName());
				pmQuadtree.addCityName(name);

				/* add city to canvas */
				Canvas.instance.addPoint(city.getName(), city.getLocalX(), city.getLocalY(),Color.BLACK);

				/* add success node to results */
				addSuccessNode(commandNode, parametersNode, outputNode);
			} catch (CityAlreadyMappedException e) {
				addErrorNode("cityAlreadyMapped", commandNode, parametersNode);
			} catch (CityOutOfBoundsException e) {
				addErrorNode("cityOutOfBounds", commandNode, parametersNode);
			}
		}
	}

	public void processMapRoad(final Element node) {
		final Element commandNode = getCommandNode(node);
		final Element parametersNode = results.createElement("parameters");
		final Element outputNode = results.createElement("output");

		final String start = processStringAttribute(node, "start", parametersNode);
		final String end = processStringAttribute(node, "end", parametersNode);		

		if (!citiesByName.containsKey(start)) {
			addErrorNode("startPointDoesNotExist", commandNode, parametersNode);
		}else if (!citiesByName.containsKey(end)) {
			addErrorNode("endPointDoesNotExist", commandNode, parametersNode);
		}else if (start.equals(end)) {
			addErrorNode("startEqualsEnd", commandNode, parametersNode);
		}else if (pmQuadtree.isInIso(start) || pmQuadtree.isInIso(end)) {
			addErrorNode("startOrEndIsIsolated", commandNode, parametersNode);
		} else {
			City begin = citiesByName.get(start);
			City ending = citiesByName.get(end);

			/* insert city into PM Quadtree */
			pmQuadtree.addRoad(begin, ending); 

			/* add city to canvas */
			Canvas.instance.addLine(begin.getLocalX(), begin.getLocalY(),
					ending.getLocalX(), ending.getLocalY(), Color.BLACK);

			/* add success node to results */
			final Element createdRoad = results.createElement("roadCreated");
			createdRoad.setAttribute("start", begin.getName());
			createdRoad.setAttribute("end", ending.getName());
			outputNode.appendChild(createdRoad);
			addSuccessNode(commandNode, parametersNode, outputNode);
		}
	}

	/**
	 * Processes a saveMap command. Saves the graphical map to a given file.
	 * 
	 * @param node
	 *            saveMap command to be processed
	 * @throws IOException
	 *             problem accessing the image file
	 */
	public void processSaveMap(final Element node) throws IOException {
		final Element commandNode = getCommandNode(node);
		final Element parametersNode = results.createElement("parameters");

		final String name = processStringAttribute(node, "name", parametersNode);

		final Element outputNode = results.createElement("output");

		/* save canvas to '<name>.png' */
		Canvas.instance.save(name);

		/* add success node to results */
		addSuccessNode(commandNode, parametersNode, outputNode);
	}

	/**
	 * Prints out the structure of the PR Quadtree in a human-readable format.
	 * 
	 * @param node
	 *            printPMQuadtree command to be processed
	 */
	public void processPrintPMQuadtree(final Element node) {
		final Element commandNode = getCommandNode(node);
		final Element parametersNode = results.createElement("parameters");
		final Element outputNode = results.createElement("output");

		processIntegerAttribute(node, "remoteX", parametersNode);
		processIntegerAttribute(node, "remoteY", parametersNode);
		
		if (pmQuadtree.isEmpty()) {
			/* empty PMQuadtree */
			addErrorNode("mapIsEmpty", commandNode, parametersNode);
		} else {
			/* print PMQuadtree */
			final Element quadtreeNode = results.createElement("quadtree");
			/* order is 3 because that is only what we need to know */
			quadtreeNode.setAttribute("order", "3");
			printPMQuadtreeHelper(pmQuadtree.getRoot(), quadtreeNode);

			outputNode.appendChild(quadtreeNode);

			/* add success node to results */
			addSuccessNode(commandNode, parametersNode, outputNode);
		}
	}

	/**
	 * Traverses each node of the PMQuadtree.
	 * 
	 * @param currentNode
	 *            PMQuadtree node being printed
	 * @param quadNode
	 *            quad node representing the current PMQuadtree node
	 */
	private void printPMQuadtreeHelper(final Node currentNode,
			final Element quadNode) {

		if (currentNode.getType() == Node.WHITE) {
			Element white = results.createElement("white");
			quadNode.appendChild(white);
		} else {
			if (currentNode.getType() == Node.BLACK) {
				/* leaf node */
				final Black currentBlack = (Black) currentNode;
				int roadSize = currentBlack.getRoadsSize();
				final Element black = results.createElement("black");

				if (currentBlack.hasCity()){
					roadSize++;
					String title = "city";
					if (pmQuadtree.isInIso(currentBlack.getCity())){
						title = "isolatedCity";
					}

					final Element city = results.createElement(title);
					city.setAttribute("name", currentBlack.getCity().getName());
					city.setAttribute("color", currentBlack.getCity().getColor());
					city.setAttribute("localX", Integer.toString((int) currentBlack.getCity().getLocalX()));
					city.setAttribute("localY", Integer.toString((int) currentBlack.getCity().getLocalY()));
					city.setAttribute("remoteX", Integer.toString((int) currentBlack.getCity().getRemoteX()));
					city.setAttribute("remoteY", Integer.toString((int) currentBlack.getCity().getRemoteY()));
					city.setAttribute("radius", Integer.toString((int) currentBlack.getCity().getRadius()));

					black.appendChild(city);
				}

				black.setAttribute("cardinality", Integer.toString(roadSize));

				if (currentBlack.getRoadsSize() > 0) {
					for(QEdge edge : currentBlack.getRoads()) {
						final Element road = results.createElement("road");
						road.setAttribute("end", edge.getEndName());
						road.setAttribute("start", edge.getStartName());
						black.appendChild(road);
					}
				}
				quadNode.appendChild(black);
			} else {
				/* internal node */
				final Gray currentGray = (Gray) currentNode;
				final Element gray = results.createElement("gray");
				gray.setAttribute("x", Integer.toString((int) currentGray.getCenterX()));
				gray.setAttribute("y", Integer.toString((int) currentGray.getCenterY()));
				for (int i = 0; i < 4; i++) {
					printPMQuadtreeHelper(currentGray.getChild(i), gray);
				}
				quadNode.appendChild(gray);
			}
		}
	}

	/**
	 * Finds the mapped cities within the range of a given point.
	 * 
	 * @param node
	 *            rangeCities command to be processed
	 * @throws IOException
	 */
	public void processRangeCities(final Element node) throws IOException {
		final Element commandNode = getCommandNode(node);
		final Element parametersNode = results.createElement("parameters");
		final Element outputNode = results.createElement("output");

		final TreeSet<City> citiesInRange = new TreeSet<City>(new CityNameComparator());

		/* extract values from command */
		final int remoteX = processIntegerAttribute(node, "remoteX", parametersNode);
		final int remoteY = processIntegerAttribute(node, "remoteY", parametersNode);
		final int radius = processIntegerAttribute(node, "radius",
				parametersNode);

		String pathFile = "";
		if (node.getAttribute("saveMap").compareTo("") != 0) {
			pathFile = processStringAttribute(node, "saveMap", parametersNode);
		}

		/* get cities within range */
		final Point2D.Double point = new Point2D.Double(remoteX, remoteY);
		rangeCitiesHelper(point, radius, pmQuadtree.getRoot(), citiesInRange);

		/* print out cities within range */
		if (citiesInRange.isEmpty()) {
			addErrorNode("noCitiesExistInRange", commandNode, parametersNode);
		} else {
			/* get city list */
			final Element cityListNode = results.createElement("cityList");
			for (City city : citiesInRange) {
				addCityNode(cityListNode, "city", city);
			}
			outputNode.appendChild(cityListNode);

			/* add success node to results */
			addSuccessNode(commandNode, parametersNode, outputNode);

			if (pathFile.compareTo("") != 0) {
				if(radius != 0) 
					Canvas.instance.addCircle(remoteX, remoteY, radius, Color.BLUE, false);
				Canvas.instance.save(pathFile);
				if(radius != 0) 
					Canvas.instance.removeCircle(remoteX, remoteY, radius, Color.BLUE, false);
			}
		}
	}

	/**
	 * Finds the mapped cities within the range of a given point.
	 * 
	 * @param node
	 *            rangeCities command to be processed
	 * @throws IOException
	 */
	public void processRangeRoads(final Element node) throws IOException {

		final Element commandNode = getCommandNode(node);
		final Element outputNode = results.createElement("output");
		final Element parametersNode = results.createElement("parameters");

		final TreeSet<QEdge> roadsInRange = new TreeSet<>(new RoadComparator());

		final int x = processIntegerAttribute(node, "x", parametersNode);
		final int y = processIntegerAttribute(node, "y", parametersNode);
		final int radius = processIntegerAttribute(node, "radius", parametersNode);

		String saveFile = "";
		if (!node.getAttribute("saveMap").equals("")) 
			saveFile = processStringAttribute(node, "saveMap", parametersNode);

		/* get cities within range */
		final Point2D.Double point = new Point2D.Double(x, y);
		rangeRoadsHelper(point, radius, pmQuadtree.getRoot(), roadsInRange);

		/* print out cities within range */
		if (roadsInRange.isEmpty()) {
			addErrorNode("noRoadsExistInRange", commandNode, parametersNode);
		} else {
			/* get road list */
			final Element roadListNode = results.createElement("roadList");
			for (QEdge road : roadsInRange) {
				addRoadNode(roadListNode, road);
			}

			outputNode.appendChild(roadListNode);

			/* add success node to results */
			addSuccessNode(commandNode, parametersNode, outputNode);

			if (saveFile.compareTo("") != 0) {
				//same as previous method
				if(radius != 0) 
					Canvas.instance.addCircle(x, y, radius, Color.BLUE, false);
				Canvas.instance.save(saveFile);
				if(radius != 0) //not sure about this
					Canvas.instance.removeCircle(x, y, radius, Color.BLUE, false);
			}
		}
	}

	/**
	 * Checks whether the point's radius falls in the roadsInRange set of roads 
	 * @param point To be measured from
	 * @param radius of the point
	 * @param node Uses the Quad-tree
	 * @param roadsInRange Set of roads
	 */
	private void rangeRoadsHelper(final Point2D.Double point, final int radius, 
			final Node node, final TreeSet<QEdge> roadsInRange) {

		final Circle2D.Double circle = new Circle2D.Double(point, radius);

		if (node.getType() == Node.BLACK && ((Black)node).getRoadsSize() > 0) {
			final Black black = (Black) node;
			TreeSet<QEdge> roads = black.getRoads();

			for (QEdge road : roads){
				//final double distance = road.ptLineDist(point);
				final double distance = road.ptSegDist(point);
				//System.out.println("--> " + road.getStartName() + "," + road.getEndName()+ " dist: " + distance);
				if (distance <= radius){
					/* road is in range */
					roadsInRange.add(road);
				}
			}
		} else if (node.getType() == Node.GRAY) {
			/* check each quadrant of gray node */
			final Gray gray = (Gray) node;

			for (int i = 0; i < 4; i++) {
				if (pmQuadtree.intersects(circle, gray.getChildRegion(i))) {
					rangeRoadsHelper(point, radius, gray.getChild(i),
							roadsInRange);
				}
			}
		}
	}


	/**
	 * Determines if any roads within the PMQuadtree are within 
	 * the radius of a given point.
	 * 
	 * @param point
	 *            point from which the cities are measured
	 * @param radius
	 *            radius from which the given points are measured
	 * @param node
	 *            PM3Quadtree node being examined
	 * @param citiesInRange
	 *            a list of cities found to be in range
	 */
	private void rangeCitiesHelper(final Point2D.Double point,
			final int radius, final Node node, final TreeSet<City> citiesInRange) {

		if (node.getType() == Node.BLACK && ((Black) node).hasCity()) {
			final Black black = (Black) node;
			final double distance = point.distance(black.getCity().toPoint2D());
			if (distance <= radius) {
				/* city is in range */
				final City city = black.getCity();
				citiesInRange.add(city);
			}
		} else if (node.getType() == Node.GRAY) {
			/* check each quadrant of internal node */
			final Gray internal = (Gray) node;

			final Circle2D.Double circle = new Circle2D.Double(point, radius);
			for (int i = 0; i < 4; i++) {
				if (pmQuadtree.intersects(circle, internal.getChildRegion(i))) {
					rangeCitiesHelper(point, radius, internal.getChild(i),
							citiesInRange);
				}
			}
		}
	}

	/**
	 * Finds the nearest city to a given point.
	 * 
	 * @param node
	 *            nearestCity command being processed
	 */
	public void processNearestCity(Element node) {
		final Element commandNode = getCommandNode(node);
		final Element parametersNode = results.createElement("parameters");
		final Element outputNode = results.createElement("output");

		/* extract attribute values from command */
		final int x = processIntegerAttribute(node, "localX", parametersNode);
		final int y = processIntegerAttribute(node, "localY", parametersNode);
		final int remX = processIntegerAttribute(node, "remoteX", parametersNode);
		final int remY = processIntegerAttribute(node, "remoteY", parametersNode);

		final Point2D.Float point = new Point2D.Float(x, y);

		if (citiesByName.size() <= 0) {
			addErrorNode("cityNotFound", commandNode, parametersNode);
		} else if (pmQuadtree.hasCites() && pmQuadtree.getRoot().getType() == Node.BLACK) {
			addErrorNode("cityNotFound", commandNode, parametersNode);
		} else if (pmQuadtree.getRoot().getType() == Node.BLACK && pmQuadtree.hasCites() 
				&& pmQuadtree.isInIso(pmQuadtree.getRoot().getCity())) {
			addErrorNode("cityNotFound", commandNode, parametersNode);
		} 
		else {

			City n = nearestCityHelper(pmQuadtree.getRoot(), point);

			if (n == null) {
				addErrorNode("cityNotFound", commandNode, parametersNode);
				return;
			}

			addCityNode(outputNode, "city", n);

			addSuccessNode(commandNode, parametersNode, outputNode);
		}
	}

	/**
	 * @param root root of the PMQuadtree
	 * @param point point to calculate the distances from
	 */
	private City nearestCityHelper(Node root, Point2D.Float point) {
		PriorityQueue<QuadrantDistance> q = new PriorityQueue<QuadrantDistance>();
		Node currNode = root;
		while (currNode.getType() != Node.BLACK) {
			if (currNode.getType() != Node.WHITE) {
				Gray g = (Gray) currNode;
				for (int i = 0; i < 4; i++) {
					Node kid = g.children[i];

					if (kid.getType() == Node.GRAY || 
							(kid.getType() == Node.BLACK && ((Black) kid).hasCity() &&
							!pmQuadtree.isInIso(((Black) kid).getCity()))) {
						QuadrantDistance test = new QuadrantDistance(kid, point);
						if (!q.contains(test))
							q.add(test);
					}
				}
			}
			if(!q.isEmpty()) currNode = q.remove().quadtreeNode;
			else return null;
		}
		return ((Black) currNode).getCity();
	}

	/**
	 * Finds the nearest unmapped city to a given point.
	 * 
	 * @param node
	 *            nearestCity command being processed
	 */
	public void processNearestIsoCity(Element node) {
		final Element commandNode = getCommandNode(node);
		final Element parametersNode = results.createElement("parameters");
		final Element outputNode = results.createElement("output");
		//Same as above
		final int x = processIntegerAttribute(node, "x", parametersNode);
		final int y = processIntegerAttribute(node, "y", parametersNode);

		final Point2D.Float point = new Point2D.Float(x, y);

		if (citiesByName.size() <= 0) {
			addErrorNode("cityNotFound", commandNode, parametersNode);
			return;
		}

		if (!pmQuadtree.hasIsoCites()){
			addErrorNode("cityNotFound", commandNode, parametersNode);
			return;
		}

		if (pmQuadtree.getRoot().getType() == Node.WHITE) {
			addErrorNode("cityNotFound", commandNode, parametersNode);
		} else {
			City n = nearestIsoCityHelper(pmQuadtree.getRoot(), point);
			addCityNode(outputNode, "isolatedCity",  n);

			addSuccessNode(commandNode, parametersNode, outputNode);
		}
	}

	/**
	 * sorts for isolated cities
	 */
	private City nearestIsoCityHelper(Node root, Point2D.Float point) {
		PriorityQueue<QuadrantDistance> q = new PriorityQueue<QuadrantDistance>();
		Node currNode = root;
		while (currNode.getType() != Node.BLACK) {
			Gray g = (Gray) currNode;
			for (int i = 0; i < 4; i++) {
				Node kid = g.children[i];

				if (kid.getType() == Node.GRAY || 
						(kid.getType() == Node.BLACK && ((Black) kid).hasCity() &&
						pmQuadtree.isInIso(((Black) kid).getCity()))) {
					QuadrantDistance test = new QuadrantDistance(kid, point);
					if (!q.contains(test))
						q.add(test);
				}
			}
			currNode = q.remove().quadtreeNode;
		}
		return ((Black) currNode).getCity();
	}

	/**
	 * Finds the nearest road from the given point
	 * @param node
	 *             nearest Road command to be processed
	 */
	public void processNearestRoad(Element node) {
		final Element commandNode = getCommandNode(node);
		final Element parametersNode = results.createElement("parameters");
		final Element outputNode = results.createElement("output");

		final int x = processIntegerAttribute(node, "x", parametersNode);
		final int y = processIntegerAttribute(node, "y", parametersNode);

		final Point2D.Float point = new Point2D.Float(x, y);

		if (!pmQuadtree.hasRoads()){
			addErrorNode("roadNotFound", commandNode, parametersNode);
			return;
		}

		if (pmQuadtree.getRoot().getType() == Node.WHITE) {
			addErrorNode("cityNotFound", commandNode, parametersNode);
		} else {

			QEdge edge = pmQuadtree.closestRoad(point);
			addRoadNode(outputNode, edge);

			addSuccessNode(commandNode, parametersNode, outputNode);
		}
	}

	/**
	 * 
	 * @param node
	 * 					nearestCity to Road command to be processed
	 */
	public void processNearestCityToRoad(Element node) {
		final Element commandNode = getCommandNode(node);
		final Element parametersNode = results.createElement("parameters");
		final Element outputNode = results.createElement("output");

		final String start = processStringAttribute(node, "start", parametersNode);
		final String end = processStringAttribute(node, "end", parametersNode);

		City startCity = citiesByName.get(start);
		City endCity = citiesByName.get(end);

		if (startCity == null || endCity == null) {
			addErrorNode("roadIsNotMapped", commandNode, parametersNode);
			return;
		}
		TreeSet<QEdge> list = pmQuadtree.getRoadList();
		QEdge test = new QEdge(startCity, endCity);
		if (startCity.getName().compareTo(endCity.getName()) > 0) {
			test = new QEdge(endCity, startCity);
		}

		if (test == null || !list.contains(test)) {
			addErrorNode("roadIsNotMapped", commandNode, parametersNode);
			return;
		}

		if (pmQuadtree.getRoot().getType() == Node.WHITE) {
			addErrorNode("noOtherCitiesMapped", commandNode, parametersNode);
		} else if (pmQuadtree.getRoot().getType() == Node.BLACK && pmQuadtree.hasCites() ) {
			addErrorNode("noOtherCitiesMapped", commandNode, parametersNode);
		} else if (startCity.getName().equals(endCity.getName())) {
			addErrorNode("roadIsNotMapped", commandNode, parametersNode);
		} 
		else {
			City city = nearestCityToRoadHelper(pmQuadtree.getRoot(), startCity, endCity); 
			//new Line2D.Float(st.getX(), st.getY(), ed.getX(), ed.getY()));
			if (city == null) {
				addErrorNode("noOtherCitiesMapped", commandNode, parametersNode);
			} else {
				addCityNode(outputNode, "city", city);

				addSuccessNode(commandNode, parametersNode, outputNode);
			}
		}
	}

	/**
	 * sorts for isolated cities
	 */
	private City nearestCityToRoadHelper(Node root, City st, City ed) {
		double min = Integer.MAX_VALUE;
		double distance = 0;
		QEdge road = new QEdge(st, ed);
		City ct = null;
		HashSet<String> cityName = pmQuadtree.getCityNames();

		for (Entry<String, City> entry: citiesByName.entrySet() ) {
			if (       !entry.getValue().getName().equals(st.getName()) 
					&& !entry.getValue().getName().equals(ed.getName())
					&& cityName.contains(entry.getValue().getName())) {
				distance = road.ptSegDist(entry.getValue().getLocalX(), entry.getValue().getLocalY());
				//System.out.println("distance: " + distance + " city: " + city.getName());
				if (distance < min) {
					min = distance;
					ct = entry.getValue();
				}
			}
		}
		//System.out.println("distance: " + distance + " city: " + ct.getName());
		return ct;
	}

	public void processShortestPath(Element node) throws IOException {
		final Element commandNode = getCommandNode(node);
		final Element parametersNode = results.createElement("parameters");
		final Element outputNode = results.createElement("output");

		final String start = processStringAttribute(node, "start", parametersNode);
		final String end = processStringAttribute(node, "end", parametersNode);
		String html = "";
		String map = "";
		CanvasPlus canvas = null;

		/**
		 * 					Check for saveMap and saveHTML Attributes
		 */
		if (!node.getAttribute("saveMap").equals("")) {
			map = processStringAttribute(node, "saveMap", parametersNode);
			canvas = new CanvasPlus();
			canvas.setFrameSize(spatialWidth, spatialHeight);
			/* add a rectangle to show where the bounds of the map are located */
			canvas.addRectangle(0, 0, (spatialWidth > spatialHeight) ? spatialWidth : spatialHeight, 
					(spatialWidth > spatialHeight) ? spatialWidth : spatialHeight, Color.WHITE, true);
			canvas.addRectangle(0, 0, spatialWidth, spatialHeight, Color.BLACK,
					false);
		} 
		if (!node.getAttribute("saveHTML").equals("")) {
			html = processStringAttribute(node, "saveHTML", parametersNode);
		}

		/**
		 * 					Check for possible errors
		 */ 
		if (!pmQuadtree.contains(start)) {
			addErrorNode("nonExistentStart", commandNode, parametersNode);
		} else if (!pmQuadtree.contains(end)) {
			addErrorNode("nonExistentEnd", commandNode, parametersNode);
		} else if (!pmQuadtree.containRoad(start) || !pmQuadtree.containRoad(end)) {
			addErrorNode("noPathExists", commandNode, parametersNode);
		} else {
			//                         Call ShortestPath to do the work
			TreeSet<QEdge> connectedRoadSet = pmQuadtree.getRoadList();
			HashSet<String> roadPointsSet = pmQuadtree.getRoadPoints();
			HashMap<String, ArrayList<String>> bigList = new HashMap<String, ArrayList<String>>();

			/**
			 * 							Create Space for all mapped roads in a adjacency list structure 
			 */
			for(String string: roadPointsSet) {
				bigList.put(string, new ArrayList<String>());
			}

			/**
			 * 							Put all connected Roads to every City
			 */
			for(QEdge road: connectedRoadSet) {
				String startName = road.getStartName();
				String endName = road.getEndName();
				if(bigList.get(startName) != null && !bigList.get(startName).contains(endName)) {
					bigList.get(startName).add(endName);
				}
				if(bigList.get(endName) != null && !bigList.get(endName).contains(startName)) {
					bigList.get(endName).add(startName);
				}
			}

			Element resultNode = shortestPath(start, end, roadPointsSet, bigList, 
					node, outputNode, parametersNode, commandNode, canvas);

			if(resultNode.getNodeName().equals("success")) {
				if (canvas!=null) {
					/* save canvas to file with range circle */		
					canvas.save(map);
				}
				if (html.compareTo("") != 0) {
					org.w3c.dom.Document shortestPathDoc;
					try {
						shortestPathDoc = XmlUtility.getDocumentBuilder().newDocument();
						org.w3c.dom.Node spNode = shortestPathDoc.importNode(resultNode, true);
						shortestPathDoc.appendChild(spNode);
						XmlUtility.transform(shortestPathDoc, new File("shortestPath.xsl"), new File(html + ".html"));
					} catch (ParserConfigurationException e1) {
						e1.printStackTrace();
					} catch (TransformerException e1) {
						e1.printStackTrace();
					}
				}
			}

		}
	}

	/**
	 * 
	 * @param start
	 * @param end
	 * @param set Contains the roads that are mapped
	 */
	private Element shortestPath(String start, String end, HashSet<String> vertices, HashMap<String, ArrayList<String>> bigList,
			Element node, Element outputNode, Element parametersNode, Element commandNode, CanvasPlus canvas) {
		String pathLength ="";

		@SuppressWarnings("unchecked")
		HashSet<String> remaining = (HashSet<String>) vertices.clone();		//Clone()?
		HashSet<String> used = new HashSet<String>();
		HashMap<String, Double> distance = new HashMap<String, Double>();
		HashMap<String, String> parent = new HashMap<>();

		Double max = (double) (Integer.MAX_VALUE - 100);
		String nextSmallest = null;
		String realST = start;
		Stack<String> stack = new Stack<>();
		LinkedList<String> q = new LinkedList<String>();
		Arc2D.Double arc = new Arc2D.Double();

		for(String s: bigList.keySet()) {
			if(!s.equals(start)) {
				distance.put(s, Double.MAX_VALUE);
			} else {
				distance.put(s, 0.00);
			}
		}

		while(!remaining.isEmpty()) {

			ArrayList<String> adjacent = bigList.get(start);
			if(adjacent != null) {
				for(String vertex: adjacent) {
					if(remaining.contains(vertex)) {
						Point2D.Float p1 = new Point2D.Float(citiesByName.get(start).getLocalX(), citiesByName.get(start).getLocalY());
						Point2D.Float p2 = new Point2D.Float(citiesByName.get(vertex).getLocalX(), citiesByName.get(vertex).getLocalY());
						double dist = distance.get(start) + distance(p1, p2);
						if(distance.get(vertex) > dist) {
							distance.put(vertex, dist);
							parent.put(vertex, start);
						}
					}
				}
			}

			for(Entry<String, Double> entry: distance.entrySet()) {
				if(remaining.contains(entry.getKey()) && entry.getValue() <= max) {
					if (entry.getValue()==max && entry.getKey().compareTo(nextSmallest) <= 0) {
						nextSmallest = entry.getKey();
						max = entry.getValue();
					}
					else if (entry.getValue() < max) {
						nextSmallest = entry.getKey();
						max = entry.getValue();
					} 
				}
			}

			if(max == Integer.MAX_VALUE - 100) {
				//System.out.println("going to break");
				break;
			}

			start = nextSmallest;
			max = (double) (Integer.MAX_VALUE - 100);

			remaining.remove(start);
			used.add(start); 
		}

		/**
		 * 							We should have shortest Path a source to all other vertices
		 */

		String curr = end;
		while(curr != null && !curr.equals(realST)) { 

			q.addFirst(curr);
			stack.push(curr);
			curr = parent.get(curr);
		}
		q.addFirst(realST);
		stack.push(realST);

		/**
		 * 							Put it in result's attributes
		 */
		if(curr == null)
			stack = null;

		if(stack == null) {
			Element errorNode = addErrorNode("noPathExists", commandNode, parametersNode);
			return errorNode; //"errorNode"
		} else {
			int scale = 3;
			pathLength = String.valueOf(BigDecimal.valueOf(distance.get(end)).setScale(scale, BigDecimal.ROUND_HALF_UP));

			String first = "";
			String second = "";
			String third = "";
			Element pathHop = results.createElement("path");
			pathHop.setAttribute("hops", String.valueOf(stack.size()-1));
			pathHop.setAttribute("length", pathLength);

			if (canvas!=null) 
				canvas.addPoint(citiesByName.get(stack.peek()).getName(), 
						citiesByName.get(stack.peek()).getLocalX(), citiesByName.get(stack.peek()).getLocalY(), 
						Color.GREEN);

			//			TODO
			while(!stack.isEmpty()) {
				if (stack.size() == 1 && canvas!=null) {
					canvas.addPoint(stack.peek(), citiesByName.get(stack.peek()).getLocalX(), 
							citiesByName.get(stack.peek()).getLocalY(), Color.RED);
				} else if (canvas!=null) {
					if (!stack.peek().equals(realST))
						canvas.addPoint(citiesByName.get(stack.peek()).getName(), 
								citiesByName.get(stack.peek()).getLocalX(), citiesByName.get(stack.peek()).getLocalY(), Color.blue);

					String popped = stack.peek();
					City pop = citiesByName.get(popped);
					City next = citiesByName.get(stack.get(stack.size()-2));
					canvas.addLine(pop.getLocalX(), pop.getLocalY(), next.getLocalX(), next.getLocalY(), Color.blue);
				}

				Element curNode = null;
				Element direction = null;

				if (!stack.peek().equals(realST)) {
					curNode = results.createElement("road");
					curNode.setAttribute("end", (stack.peek()));
					curNode.setAttribute("start", parent.get(stack.peek()));

					Point2D p1 = null, p2 = null, p3 = null;
					if(q.size() >= 3) {
						first  = q.removeFirst();
						second = q.removeFirst();
						third  = q.removeFirst();
					}

					if(!first.equals(""))
						p1 = citiesByName.get(first).localPt;
					if(!second.equals(""))
						p2 = citiesByName.get(second).localPt;
					if(!third.equals(""))
						p3 = citiesByName.get(third).localPt;

					if(p3!=null && p2!=null && stack.size() >= 2) {
						arc.setArcByTangent(p1, p2, p3, 1);
						Double angle;
						if (arc.getAngleExtent() == -180) angle = 180.0;
						else angle = arc.getAngleExtent();
						if(arc.getAngleExtent() < -45.0 && arc.getAngleExtent() > -180.0){
							direction = results.createElement("left");
						}
						else if(angle >= 45.0 && angle <= 180 ){
							direction = results.createElement("right");
						}
						else {
							direction = results.createElement("straight");
						}
					}

					q.addFirst(third);
					q.addFirst(second);
				}

				if (curNode != null)
					pathHop.appendChild(curNode);
				if(direction!=null)
					pathHop.appendChild(direction);
				stack.pop();
			}
			outputNode.appendChild(pathHop);

			Element resultNode = addSuccessNode(commandNode, parametersNode, outputNode);
			return resultNode; //"successNode"
		}
	}


	private double distance(Float p1, Float p2) {
		double x1 = p1.getX();
		double x2 = p2.getX();
		double y1 = p1.getY();
		double y2 = p2.getY();

		return Math. sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1));
	}


	public void processAvlTree(Element node) {
		final Element commandNode = getCommandNode(node);
		final Element parametersNode = results.createElement("parameters");
		final Element outputNode = results.createElement("output");

		Element xmlNode = results.createElement("AvlGTree");

		if (!citiesByName.isEmpty()) {
			xmlNode.setAttribute("cardinality", Integer.toString(citiesByName.size())); 
			xmlNode.setAttribute("height", Integer.toString(citiesByName.height()));
			xmlNode.setAttribute("maxImbalance", Integer.toString(gVal));  

			outputNode.appendChild(xmlNode);

			citiesByName.printAvlGTree(xmlNode, results, citiesByName);

			addSuccessNode(commandNode, parametersNode, outputNode);
		} else {
			addErrorNode("emptyTree", commandNode, parametersNode);
		}
	}
 

	/**
	 * Distance between a line
	 * @author
	 */

	class QuadrantDistance implements Comparable<QuadrantDistance> {
		public Node quadtreeNode;
		private double distance;

		public QuadrantDistance(Node node, Point2D.Float pt) {
			quadtreeNode = node;
			if (node.getType() == Node.GRAY) {
				Gray gray = (Gray) node;
				distance = Shape2DDistanceCalculator.distance(pt, 
						new Rectangle2D.Float(gray.origin.x, gray.origin.y, gray.width, gray.height));
			} else if (node.getType() == Node.BLACK) {
				Black leaf = (Black) node;
				distance = pt.distance(leaf.getCity().localPt);
			} else {
				throw new IllegalArgumentException("Only leaf or internal node can be passed in");
			}
		}

		public int compareTo(QuadrantDistance qd) {
			if (distance < qd.distance) {
				return -1;
			} else if (distance > qd.distance) {
				return 1;
			} else {
				if (quadtreeNode.getType() != qd.quadtreeNode.getType()) {
					if (quadtreeNode.getType() == Node.GRAY) {
						return -1;
					} else {
						return 1;
					}
				} else if (quadtreeNode.getType() == Node.BLACK) {
					// both are black
					return ((Black) qd.quadtreeNode).getCity().getName().compareTo(
							((Black) quadtreeNode).getCity().getName());
				} else {
					// both are gray
					return 0;
				}
			}
		}
	}


		/**
	 * Maps airport in the spatial Map
	 * @param commandNode
	 */
	public void processMapAirport(Element node) {
		// TODO Auto-generated method stub
		final Element commandNode = getCommandNode(node);
		final Element parametersNode = results.createElement("parameters");
		final Element outputNode = results.createElement("output");

		final String airportName = processStringAttribute(node, "name", parametersNode);
		final String localX = processStringAttribute(node, "localX", parametersNode);
		final String localY = processStringAttribute(node, "localY", parametersNode);		
		final String remoteX = processStringAttribute(node, "remoteX", parametersNode);
		final String remoteY = processStringAttribute(node, "remoteY", parametersNode);		
		final String terminalName = processStringAttribute(node, "terminalName", parametersNode);		
		final String terminalX = processStringAttribute(node, "terminalX", parametersNode);
		final String terminalY = processStringAttribute(node, "terminalY", parametersNode);		
		final String terminalCity = processStringAttribute(node, "terminalCity", parametersNode);

		

		addSuccessNode(commandNode, parametersNode, outputNode);

	}

		public void processMst(Element commandNode) {
			// TODO Auto-generated method stub
			
		}

		public void processUnmapRoad(Element commandNode) {
			// TODO Auto-generated method stub
			
		}

		public void processUnMapTerminal(Element commandNode) {
			// TODO Auto-generated method stub
			
		}

		public void processMapTerminal(Element commandNode) {
			// TODO Auto-generated method stub
			
		}

		public void processUnMapAirport(Element commandNode) {
			// TODO Auto-generated method stub
			
		}

		public void processNearestAirport(Element commandNode) {
			// TODO Auto-generated method stub
			
		}
}
